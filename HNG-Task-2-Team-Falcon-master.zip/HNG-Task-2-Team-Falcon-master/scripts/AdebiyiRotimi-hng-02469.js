name = "Rotimi Adebiyi";
hngId = "HNG-02469";
language = "JavaScript";
email = " r.s.adebiyi@gmail.com";

function hngReturn(){

    output = console.log("Hello World, this is "+ name +" with HNG ID "+ hngId + " using " + language + " for stage 2 task." + email + ".");

    return output;
}
hngReturn();
