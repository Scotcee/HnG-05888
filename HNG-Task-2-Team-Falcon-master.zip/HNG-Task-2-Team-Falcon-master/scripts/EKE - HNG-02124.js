<script>
function myFunction(lastName, firstName, id, myLanguage, myEmail) {
  return `Hello World, this is ${lastName}, ${firstName} with ${id}, and I am using ${myLanguage} for stage 2 task. ${myEmail}`;
}
console.log (myFunction("Eke", "Chinedu", "HNG-02124", "Javascript", "ekechinedu488@gmail.com"));
</script>
