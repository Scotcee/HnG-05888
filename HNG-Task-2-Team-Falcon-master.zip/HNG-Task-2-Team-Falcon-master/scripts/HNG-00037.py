"""Second task that qualifies an intern to stage 2."""

def task(fullname,hngid, lang):
    return f"Hello World, this is {fullname} with HNGi7 ID {hngid} using {lang} for stage 2 task. {email}"


fullname= 'Philip Ireoluwa Okiokio'
hngid= 'HNG-00037'
lang= 'python'
email= 'philipokiokiocodes@gmail.com'


print(task(fullname,hngid,lang), flush= True)
