details = {'file': "Luwole.py",
           'name': "Oluwole Adetifa",
           'id': "HNG-00048",
           'output': "Hello World, this is Adetifa Oluwole with HNGi7 ID HNG-00048 using Python for stage 2 task",
           'email': "adetifaoluwole@gmail.com",
           'language': "Python",
           'status': "Pass",}

output = print(f"Hello World, this is {details['name']} with HNGi7 ID {details['id']} using {details['language']} for stage 2 task. {details['email']}")
#this is the string we are to display


def myresult():
    return output