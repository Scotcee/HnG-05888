# HNG7 TASK 2

full_name = 'Tomiwa Obanla'
hng_id = 'HNG-00056'
language = 'python'
email = 'obanlatomiwa@gmail.com'

print('Hello World, this is {} with HNGi7 ID {} using {} for stage 2 task. {}'.format(full_name, hng_id, language, email))

