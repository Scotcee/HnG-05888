const fullName = "Adeola Boluogun";
const id = "HNG-00068"; 
const language = "Javascript";
const email= "boluoguna@gmail.com";
console.log(`Hello World, this is ${fullName} with HNGi7 ID ${id} using ${language} for stage 2 task ${email}`);
