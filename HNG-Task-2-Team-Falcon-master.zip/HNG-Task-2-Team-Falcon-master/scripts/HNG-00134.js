const fullName = "Mustapha Sani";
const hng_ID = "HNG-00134";
const email = "mustapha3341@gmail.com";
const lang = "Javascript";

const myIntroScript = (fullName, hng_ID, lang, email) => {
	console.log(
		`Hello World, this is ${fullName} with HNGi7 ID ${hng_ID} using ${lang} for stage 2 task ${email}`
	);
};

myIntroScript(fullName, hng_ID, lang, email);
