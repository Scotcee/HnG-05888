var name = 'Adedolapo Aishat Toye';
var HNG_ID = 'HNG-00135';
var email = 'dolapo.toye@yahoo.com';
var lang = "JavaScript";
console.log("Hello World, this is " + name + " with HNGi7 ID " + HNG_ID + " using " + lang + " for stage 2 task. " + email);
