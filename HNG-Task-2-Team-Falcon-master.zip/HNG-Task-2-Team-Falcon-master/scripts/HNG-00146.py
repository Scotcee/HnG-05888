fullname = "Deji Ajibola"
id = "HNG-00146"
language = "Python"
email = "harjhibolar@gmail.com"

stuff = "Hello World, this is {} with HNGi7 ID {} using {} for stage 2 task. {}"

print(stuff.format(fullname, id, language, email),flush = True)
