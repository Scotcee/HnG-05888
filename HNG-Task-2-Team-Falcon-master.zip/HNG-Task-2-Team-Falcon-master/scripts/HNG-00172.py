
name  = "Musa Abdulwadud Olagoke"
hngId = "HNG-00172"
language = "python"
email = "wadva474@gmail.com"
print("Hello World, this is %s with HNGi7 ID %s using %s for stage 2 task. %s"%(name,hngId,language,email))
