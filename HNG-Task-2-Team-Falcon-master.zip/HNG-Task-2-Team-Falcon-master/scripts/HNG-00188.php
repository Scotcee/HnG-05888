<?php

echo "Hello World! This is Solomon Kinyua with HNGi7 ID 00188 using PHP for stage 2 task. My registered email is 2s5k4m@gmail.com"

?>