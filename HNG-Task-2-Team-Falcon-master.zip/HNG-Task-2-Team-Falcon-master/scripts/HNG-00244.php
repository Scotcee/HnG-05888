<?php

	$id = "HNG-00244";
	$name = "Fabamise Adeoluwa";
	$email = "fabamiseadeolu@gmail.com";
	$language = "PHP";


	echo "Hello World, this is {$name} with HNGi7 ID {$id} using {$language} for stage 2 task. {$email}";
  
?>
