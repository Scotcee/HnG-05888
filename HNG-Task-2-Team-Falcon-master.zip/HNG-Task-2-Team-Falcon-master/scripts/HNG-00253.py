#HNGi7 stage 2 task
name = 'Bello Abdulmalik Kehinde'
hngi7_id = 'HNG-00253'
language = 'python'
email = 'adedotunomomeji@gmail.com'
print(f'Hello World, this is {name} with HNGi7 ID {hngi7_id} using {language} for stage 2 task. {email}',flush=True)
