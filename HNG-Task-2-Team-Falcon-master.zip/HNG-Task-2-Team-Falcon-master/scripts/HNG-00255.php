master
 <?php
       $myOutput = "Hello World, this is Abolarin Victor with HNGI7 ID HNG-00255 using php for stage 2 task.  iam.vee01@gmail.com";
       echo $myOutput; 
      

<?php 
echo "Hello World, this is Abolarin Victor with HNGi7 ID HNG-00255 using Php for stage 2 task."
submissions
?>
