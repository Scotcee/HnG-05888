const stageTask = (fullName = "Ikeh Chukwuka Favour", id = "HNG-00256", language = "javaScripi", email = "mrikehchukwuka@gmail.com") => {
  return `Hello World, this is ${fullName} with HNGi7 ID ${id} using ${language} for stage 2 task. ${email}.`;
};
console.log(stageTask());
