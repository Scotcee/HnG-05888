print ("Hello World, this is Judicaelle Ben MBOUNGOU with HNGi7 ID HNG-00304 using  Python for stage 2 task. benjudicaelle@gmail.com")
