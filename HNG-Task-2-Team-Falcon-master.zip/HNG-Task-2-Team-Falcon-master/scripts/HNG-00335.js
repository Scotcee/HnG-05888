const myFunction = () => {

    let fullname = 'Robert Ebafua';
    let hngId = 'HNG-00335';
    let devLang = 'Javascript';
    let email  = 'robertebafua@gmail.com';

    console.log(`Hello World, this is ${fullname} with HNGi7 ID ${hngId} using ${devLang} for stage 2 task. ${email}`);
};

myFunction();