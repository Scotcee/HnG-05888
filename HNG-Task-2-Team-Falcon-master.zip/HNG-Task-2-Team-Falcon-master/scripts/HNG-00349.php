<?php
$FirstName = "Damilola";
$LastName = "Omolusi";
$HNGID = "HNG-00349";
$Language = "PHP";
$Email = "goodness.omolusi@gmail.com";
echo "Hello World, this is $FirstName $LastName with HNGi7 ID $HNGID using $Language for stage 2 task. $Email";
