<?php
        $name = "Sajjad Khalid Abubakari";
        $id = "HNG-00364";
        $language = "PHP";
        $email = "captainsajjad4@gmail.com";
        $output = "Hello World, this is ".$name." with HNGi7 ID ".$id." using ".$language." for stage 2 task. ".$email."";
        echo $output;
?>
    