<?php
  $myLastName = "Ogunfusika";
  $myFirstName = "Oluwatoni";
  $myHNGID = "HNG-00419";
  $myEmail = "ogunfusika64@gmail.com";
  $myLangUsed = "PHP";
  echo "Hello World, this is ".$myLastName." ".$myFirstName." with HNGi7 ID ".$myHNGID." using ".$myLangUsed." for stage 2 task. ".$myEmail;
?>
