
let fullname = "Victoria Akpan"
let ID = "HNG-00435"
let language = "Javascript"
let email = "veedahv55@gmail.com"

console.log("Hello World, this is " + fullname + " with HNGi7 ID " + ID + " using " + language + " for stage 2 task. " + email)