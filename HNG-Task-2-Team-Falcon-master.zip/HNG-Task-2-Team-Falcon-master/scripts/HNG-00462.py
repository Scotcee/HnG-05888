full_name = "MBAYA EMMANUEL BALDWIN"
ID = "HNG-00462"
language = "Python"
email = "emmanuelbaldwin@gmail.com"

print("Hello World, this is " +full_name+" with HNGi7 ID "+ID+" using "+language+" for stage 2 task. "+email)
