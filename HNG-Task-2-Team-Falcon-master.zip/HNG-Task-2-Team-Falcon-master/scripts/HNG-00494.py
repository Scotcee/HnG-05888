full_name= 'Vivian Nwosu'
HNG_ID='HNGi7 ID HNG-00494'
language= ' python '
email= 'viviannwosu05@gmail.com'

print('Hello World, this is '+ full_name + ' with ' + HNG_ID
      +' using ' + language +'for stage 2 task.' + email, flush=True)
