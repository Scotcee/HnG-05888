const myHNGIInfo = {
  fullName: "Ismaila Hassan",
  HNGIId: "HNG-00586",
  email: "ismailah28@gmail.com",
  language: "JavaScript",
};

const displayMessage = `Hello World, this is ${myHNGIInfo.fullName} with HNGi7 ID ${myHNGIInfo.HNGIId} using ${myHNGIInfo.language} for stage 2 task. ${myHNGIInfo.email}`;

console.log(displayMessage);
