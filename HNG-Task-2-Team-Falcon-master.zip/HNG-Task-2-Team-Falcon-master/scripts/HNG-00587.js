function returnString(){
    let fullname = "Margaret Ogbor", hng_id = "HNG-00587", preferedLanguage = "javascript", emailaddress = "margaretogbor@gmail.com";
    let fullStringText = "Hello World, this is " + fullname + " with HNGi7 ID " + hng_id + " using " + preferedLanguage + " for stage 2 task. " + emailaddress;
    console.log(fullStringText);
    return fullStringText;
}
returnString()