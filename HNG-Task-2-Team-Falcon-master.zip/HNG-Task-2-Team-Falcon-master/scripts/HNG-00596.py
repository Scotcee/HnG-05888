my_name = 'Aanuoluwapo Babajide'
aanu_id = 'HNG-00596'
aanu_language = 'Python'
aanu_email = 'anubabajide@gmail.com'
print("Hello World, this is " + my_name + " with HNGi7 ID " + aanu_id + " using " + aanu_language + " for stage 2 task. " + aanu_email)

