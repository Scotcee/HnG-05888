const name = "Christian Dirisu";

const id = "HNG-00597";

const language = "Javascript";

const email = "christian.dirisu@gmail.com";

const task = () => {

    return `Hello world, this is ${name} with HNGi7 ID ${id} and email ${email} using ${language} for stage 2 task`

};

console.log(task());