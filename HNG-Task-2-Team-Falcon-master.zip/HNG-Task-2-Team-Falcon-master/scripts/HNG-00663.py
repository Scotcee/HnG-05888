#USING PYTHON TO COMPLETE HNG-17 STAGE 2 TASK

myName = 'Onadipe Daniel'
myHng_id = 'HNG-00663'
myLang = 'python'
myEmail = 'onadipedaniel@gmail.com
print(f'Hello World, this is {myName} with HNGi7 ID {myHng_id} using {myLang} for stage 2 task. {myEmail}', flush = True)
