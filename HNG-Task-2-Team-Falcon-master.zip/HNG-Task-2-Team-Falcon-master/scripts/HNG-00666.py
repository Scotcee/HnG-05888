const myFullName = `Ogbu Ezekiel Ike`;
const myHNGDetails =  `HNGi7 ID HNG-04274`;
const programmingLanguageUsed = `Javascript`;


console.log(`Hello World, this is ${myFullName} with ${myHNGDetails} using ${programmingLanguageUsed} for stage 2 task.`)
