let name = 'Oloruntoba Dare'
let id = 'HNG-00669'
let lang = 'JavaScript'
let email = 'd.toba91@gmail.com'
console.log(`Hello World, this is ${name} with HNGi7 ID ${id} using ${lang} for stage 2 task. ${email}`)
