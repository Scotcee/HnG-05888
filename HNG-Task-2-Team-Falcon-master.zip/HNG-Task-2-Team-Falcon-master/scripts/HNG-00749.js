const outputDetails = () => {
  let fullName, ID, lang, emailAddress;
  fullname = 'Akinleye Oyinbayode Peters';
  ID = 'HNG-00749';
  lang = 'JavaScript'
  emailAddress = 'oyinbayode75@gmail.com'
  console.log(`Hello World, this is ${fullname} with HNGi7 ID ${ID} using ${lang} for stage 2 task. ${emailAddress}`);
}
outputDetails();
