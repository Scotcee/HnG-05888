console.log("Hello World, this is Eucharia Chidiebere Okoli with HNGi7 ID HNG-00750 using JavaScript for stage 2 task");
