var FullName = "Oyebanji Oyinkansola";
var HNGID = "HNG-00775";
var Email = "oyebanjiioyinkansola@gmail.com";
var Language = "Javascript";
console.log("Hello World,this is" + FullName + "with HNGi7 ID"+ HNGID +"using" + Language+"for stage 2 task".+ Email)

