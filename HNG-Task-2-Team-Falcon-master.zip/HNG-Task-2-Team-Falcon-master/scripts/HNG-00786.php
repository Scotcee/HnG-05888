<?php
print "Hello world!<br>";
print "This is Anigbogu Chioma Paschaline, with ";
print "HNGi7-00786 ";
print "using (PHP) ";
print "for stage 2 task<br>";
print "Name: Anigbogu Chioma Paschaline<br>";
print "Id: HNG-00786<br>";
$txt = "Email: prisca4luv2@gmail.com";

print $txt
?> 
