let name = "Moronfolu Olufunke";
let email = "moronfolu.motunrayo1@gmail.com";
let hngId  = "HNG-00809";
let lang = "javaScript";

function description(){
    console.log(`Hello World, this is ${name} with HNGi7 ID ${hngId} using ${lang} for stage 2 task. ${email}`);
}
description();


