    <?php
    $name = "Bello Yakub";
    $id = "HNG-00830";
    $language = "PHP";
    $email = "hyaaquub@gmail.com";
        echo '<p>Hello World, this is [$name] with HNGi7 ID [$id] using [$language] for stage 2 task. [$email]</p>'; 
        ?>
