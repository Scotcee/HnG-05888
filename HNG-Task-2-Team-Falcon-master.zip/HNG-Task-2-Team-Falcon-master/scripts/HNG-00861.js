const myHNGTask2 = () => {
    const fullName = `Alao Abiodun AbdulRahman`;
    const hngId = `HNG-00861`;
    const programmingLanguage = `JavaScript`;
    const email = `abiodundev@gmail.com`
    const result = `Hello World, this is ${fullName} with HNGi7 ID ${hngId} using ${programmingLanguage} for stage 2 task. ${email}`;
    console.log(result);
}

myHNGTask2();