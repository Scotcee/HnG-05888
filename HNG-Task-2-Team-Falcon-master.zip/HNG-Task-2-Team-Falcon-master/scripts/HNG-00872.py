
full_name = "Oluwagbenga Olawolu"
hng_id = "HNG-00872"
email = "gbemigaolawolu@gmail.com"
language = "Python"

print("Hello World, this is %s with HNGi7 ID %s using %s for stage 2 task. %s"%(full_name, hng_id, language, email), flush=True)