console.log(
  "Hello World, this is Makwe Quintin with HNGi7 ID HNG-00884 using javascript for stage 2 task. kelvinmakwe@gmail.com"
);
