//a simple "hello world" script for task2 spelling out my name and hngid for hnginternship_i7 task2

const name = "Ukponoabasi Nnah";
const hngid = "HNG-00896";
const language = "javascript";
const email = "kruzabasi@gmail.com";


console.log("Hello World, this is " + name + " with HNGi7 ID " + hngid + " using " + language + " for stage 2 task");


//this script was written in javascript by HNG-00896
