first_name = "Bolaji"
last_name ="Alabi"
id = "HNG-00998"
language ="Python"
email = "alabibolaji78@gmail.com"


def printData ():
    full_name = (first_name+" "+ last_name);
    print("Hello World, this is "+ full_name + " with HNGi7 ID " + id + " using " + language +" for stage 2 task.", email, flush=True)
    return;

printData()
