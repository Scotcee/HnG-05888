
var name = 'Kelvin Pere';
var HNG_ID = 'HNG-00999';
var email = 'perekelvin66@gmail.com';
var lang = "JavaScript";
console.log("Hello World, this is " + name + " with HNGi7 ID " + HNG_ID + " using " + lang + " for stage 2 task " + email);
