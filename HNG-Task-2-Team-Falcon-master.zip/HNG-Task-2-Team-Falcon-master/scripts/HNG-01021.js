function odizee () {
       
       var helloWorld = "Hello World, this is Ighogboja Odiri with HNGi7 ID HNG-01021 using JavaScript for stage 2 task. odizeeplatform@gmail.com"
       return helloWorld;

   } 
          
console.log(odizee());
