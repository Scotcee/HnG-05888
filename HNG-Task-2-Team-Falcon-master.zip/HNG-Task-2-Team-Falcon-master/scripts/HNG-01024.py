print("Hello World, this is Joshua Okwara with HNGi7 ID HNG-01024 using python for stage 2 task. okwajoshltd@gmail.com")
