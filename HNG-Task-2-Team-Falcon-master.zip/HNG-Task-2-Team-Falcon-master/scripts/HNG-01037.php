    <?php
    $fullname = "Akinpelu Basheeroh";
    $hngid = "HNG-01037";
    $language = "PHP";
    $email = "basheeroh22@gmail.com";
        echo '<p>Hello World, this is [$fullname] with HNGi7 ID [$hngid] using [$language] for stage 2 task. [$email]</p>'; 
        ?>
