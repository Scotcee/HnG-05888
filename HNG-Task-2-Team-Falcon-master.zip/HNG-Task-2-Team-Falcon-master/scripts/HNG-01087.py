

Hello =  "Hello World, this is Olanrewaju Joshua with HNGi7 ID HNG-01087 using Python for stage 2 task. tthrones20@gmail.com"

print(Hello)
