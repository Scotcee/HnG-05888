
#This is my Python version of Task 2 for team-falcon
full_name = 'Michael Ashi'
HNDid = 'HNG-01089'
language_type = 'python'
email = 'ashimichaelashi@gmail.com'
print(f'Hello World, this is {full_name} with HNGi7 ID {HNDid} using {language_type} for stage 2 task.\nMy email is: {email}', flush = True)
