intro = 'Hello World, this is Ato Sam with HNGi7 ID HNG-01095 using Python for stage 2 task. theatosam@gmail.com'
print(intro, flush=True)
