const name = "Okpala Faith";
const id = "HNG-01108";
const language = "Javascript";
const email = "okpalafaith1@gmail.com";


console.log(`Hello World, this is ${name} with HNGi7 ID ${id} using ${language} for stage 2 task. ${email}`);