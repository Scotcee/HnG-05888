theTask = () => {
    let task = {
        id: "Ayo Solomon",
        hid: "HNG-01134",
        lang: "Javascript",
        email: "ayoseunsolomon@gmail.com",
    }
    let needed = `Hello World, this is ${task.id} with HNGi7 ID ${task.hid} using ${task.Lang} for stage 2 Task`
    console.log(needed)
}
theTask()
