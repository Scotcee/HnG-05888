function introduction() {
  let myName = "Meduna Oluwafemi";
  let id = "HNG-01155";
  let email = "femimeduna@gmail.com";
  let language = "Javascript";
  let intro = `Hello World this is ${myName} with HNGI7-ID ${id} using ${language} for stage 2 task.${email}`;

  return intro;
}
console.log(introduction());
