let myName = "Oluwapelumi Odumosu";
let myId = "HNG-01169";
let scriptLanguage = "JavaScript";
let myEmail = "odumosuoluwapm@gmail.com";
console.log("Hello World, this is " + myName + " with HNGi7 ID " + myId + " using " + scriptLanguage + " for stage 2 task");
