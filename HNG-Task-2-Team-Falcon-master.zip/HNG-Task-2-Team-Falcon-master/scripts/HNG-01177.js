const name = 'Gabriel Emmanuel';
const email = 'contacteghosa@gmail.com';
const HNG_ID = 'HNG-01177';
const lang = "Javascript";
console.log("Hello World, this is " + name + " with HNGi7 ID " + HNG_ID + " using " + lang + " for stage 2 task");
