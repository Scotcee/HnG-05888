<?php
$names="Onalenna Matsididi";
$id="HNG-01181";
$email="o.matsididi@gmail.com";
$language="PHP";

echo"Hello World, this is $names with HNGi7 ID $id using $language for stage 2 task. $email";

?>
