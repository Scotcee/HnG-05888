<?php
$name = "Victor Akanmidu";
$id = "HNG-01183";
$language = "PHP";
$email = "victor.mrcertified@gmail.com";

echo "Hello World, this is {$name} with HNGi7 ID {$id} using {$language} for stage 2 task. {$email}";
?>
