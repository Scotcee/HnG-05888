(function(){
    const Intern = {
        FullName: 'NSSO EKEME Hugues Jospin',
        Email: 'nssoekeme@gmail.com',
        Id : 'HNG-01225',
        Language: 'JavaScript'
    }

    console.log(`Hello World, this is ${Intern.FullName} with  HNGi7 ID ${Intern.Id} using ${Intern.Language} for stage 2 task.`)
})();