let fullname = 'Obidike Lawrence',
      hngid  =  'HNG-01239',
      email  =  'obidikelawrence11@gmail.com',
    language = 'JavaScript';

    function Task2 (){
       return `Hello World, this is ${fullname} with HNGi7 ID ${hngid} using ${language} for stage 2 task. ${email}`
    };

    console.log(Task2());