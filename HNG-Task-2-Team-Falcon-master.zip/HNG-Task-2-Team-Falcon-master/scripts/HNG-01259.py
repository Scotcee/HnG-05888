print("Hello World, this is Akere Mukhtar with HNGi7 ID HNG-01259 using Python for stage 2 task. akeremukhtar10@gmail.com")
