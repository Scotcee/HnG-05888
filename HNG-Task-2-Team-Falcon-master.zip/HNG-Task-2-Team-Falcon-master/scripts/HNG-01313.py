#################################
# HNG INTERNSHIP STAGE 2 TASK
# CREATED BY ROTIMI
################################

my_details = "Hello World, this is {full_name} with HNGi7 ID {id} using {language} for stage 2 task. {email}".format(
	full_name = 'Bola-Rotimi Praise.O',
	id = 'HNG-01313',
	language = 'Python',
	email = 'opraise139@gmail.com',
)

print(my_details, flush=True)
