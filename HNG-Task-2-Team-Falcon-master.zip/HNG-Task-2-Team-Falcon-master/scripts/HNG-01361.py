name = 'Olatoye Daniel Timilehin'
id = 'HNG-01361'
language = 'Python'
email = 'olatoyedan@gmail.com'
final_result = "Hello World, this is " + name + " with HNGi7 ID " + id + " using " + language + " for stage 2 task. " + email
print(final_result)
