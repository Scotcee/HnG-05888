var myEmail = "samuelebeagu@gmail.com"
var myId = "HNG-01432"
var output = `Hello World, this is Ebeagu Samuel with HNGi7 ID ${myId} using Javacript for stage 2 task. ${myEmail}`
console.log(output)
