def introduce(name, hngid):
    return f"Hello World, this is {name} with HNGi7 ID {hngid} using Python for stage 2 task. eberelucky64@gmail.com"

print(introduce('Ebere Lucky Uchenna', "HNG-01461"))
