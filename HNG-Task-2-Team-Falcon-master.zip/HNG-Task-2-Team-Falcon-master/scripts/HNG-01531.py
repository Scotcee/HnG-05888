name = "Ayaan Kamaal Rizvi"
ID = "HNG-01531"
email = "rizviayaan00@gmail.com"

print ("Hello World" + "," + " " + "this is" + " " + name + " " + "with HNGi7 ID" + " " + ID + " " + "using python for stage 2 task." + " " + email )
