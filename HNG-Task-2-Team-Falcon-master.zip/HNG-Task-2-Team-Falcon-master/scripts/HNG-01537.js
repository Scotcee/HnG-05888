var fullname = "Bello Mueez Omobolaji";
var ID = "HNG-01537";
var language = "Javascript";
var email = "omobolajimuhammedbello@gmail.com";
var result = "Hello World, this is ${fullname} with HNGi7 ID ${ID} using ${language} for stage 2 task. ${email}";

console.log(result);
