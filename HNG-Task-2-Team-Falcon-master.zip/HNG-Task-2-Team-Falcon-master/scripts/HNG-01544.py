
print ("Hello world, this is Adeniyi Samuel with HNGi7-01544 using Python For stage 2 task. sa7259379@gmail.com ")
