//HNGi7 TASK 2


let fullName = 'Sogbesan Teniloluwa';
let myLanguage = 'Javascript';
let emailAdress = 'sogbesanteniola@gmail.com';
console.log(`Hello World, this is ${fullName} with HNGi7 ID HNG-01551 using ${myLanguage} for stage 2 task. ${emailAdress}`);
