
function remark(){
    var email  = "lawaltoheeb231@gmail.com"
    console.log("Hello World, this is Lawal Toheeb Babatunde with HNGi7 ID HNG-01600 using Javascript for stage 2 task. "+ email)};
    remark();
