from os import statvfs_result

fullname = "Akinyemi Akinwunmi"
id = "01605"
language = "Python"
email = "akinyemiwunmi@gmail.com"
print(f"Hello world, this is {fullname} with HNGi7 ID {id} using {language} for stage 2 task. {email}" )
