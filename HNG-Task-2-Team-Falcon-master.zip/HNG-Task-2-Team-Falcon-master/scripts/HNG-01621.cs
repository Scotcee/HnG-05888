﻿using System;

namespace HNG_01621
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World, this is Sophie Obomighie with HNGi7 ID HNG-01621 using C# for stage 2 task");
        }
    }
}
