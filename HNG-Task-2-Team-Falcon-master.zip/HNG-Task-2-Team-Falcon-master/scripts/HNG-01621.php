<?php

$full_name = "Sophie Obomighie";
$ID = "HNG-01621";
$language = "PHP";
$email = "sophiecodes@gmail.com";

$script = "Hello World, this is ".$full_name." with HNGi7 ID ".$ID."  using ".$language." for stage 2 task. ".$email."";

echo $script;
?>