var project = 'Hello World, this is [Abdurrahman Musa] with HNGi7 ID [HNG-01668] using [javascript]';
 console.log(project);
