def Oyela(oruko, hngId, ede, apoti):
    return print("Hello World, this is {} with HNGi7 ID {} using {} for stage 2 task. {}".format(oruko, hngId, ede, apoti))

oruko = "Mubarak Ayelotan"
hngId = "HNG-01731"
ede = "Python"
apoti = "ayelotanm@gmail.com"

Oyela(oruko, hngId, ede, apoti)
