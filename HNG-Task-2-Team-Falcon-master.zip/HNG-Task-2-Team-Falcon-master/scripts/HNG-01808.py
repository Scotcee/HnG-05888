
def task_2():
    full_name = " Ojo Ilesanmi"
    ID = '01808'
    language = 'Python'
    email_address = 'ojoilesanmi89@gmail.com'
    print('Hello world, this is {0} with HNGi7 ID {1} using {2} for stage 2 task'.format(full_name, ID, language), flush=True)

task_2()