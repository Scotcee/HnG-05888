function logg(){
    var fullname ="Raji Abdulrazaq";
    var id ="HNG-01809";
    var language="javascript";
    var email="rajiorazaq@gmail.com";

    const myString = `Hello World, this is ${fullname} with HNGi7 ID ${id} using ${language} for stage 2 task. ${email}`
         return  console.log(myString);
}
logg()