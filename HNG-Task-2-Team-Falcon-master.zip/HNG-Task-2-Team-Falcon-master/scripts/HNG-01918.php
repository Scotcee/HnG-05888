<?php


$name = 'Abiodun Olanlokun Bakinde';

$hng_id = 'HNG-01918';

$language = 'PHP';

$email = 'abiodunolanlokunbakinde@gmail.com';

echo("Hello Word, this is " . $name . " with HNGi7 ID " . $hng_id . " using " . $language . " for stage 2 task. " . $email);
