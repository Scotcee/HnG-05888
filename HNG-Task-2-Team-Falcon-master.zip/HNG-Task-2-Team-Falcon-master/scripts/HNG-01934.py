print("Hello World, this is Okereke Nnenna Nina with HNGi7 ID HNG-01934 using python for stage 2 task")
