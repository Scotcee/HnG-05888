<?php 

$name = 'Oluwasegun Ibidokun';
$id = 'HNG-01947';
$language = 'PHP';

echo "Hello World, this is {$name} with HNGi7 ID {$id} using {$language} for stage 2 task";

?>