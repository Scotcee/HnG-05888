#HNG Task 2

full_name = 'Jokotoye Ademola Akin'
id = 'HNG-01954'
language = 'python'
email = 'jokotoyeademola95@gmail.com'

print(f'Hello World, this is {full_name} with HNGi7 ID {id} using {language} for stage 2 task. {email}')
