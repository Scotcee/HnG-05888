details = "Hello World, this is Godstime Agholor with HNGi7 ID HNG-01984 using Python for stage 2 task. agholorgodstime18@gmail.com"

print(details)
