
console.log("HELLO WORLD, this is KUFORIJI FIKUNAYO with HNGI7 ID HNG-02002 using JAVASCRIPT for stage 2 task. kuforijifikunayo@gmail.com");