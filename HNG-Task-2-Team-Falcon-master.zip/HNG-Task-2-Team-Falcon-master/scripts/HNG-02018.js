//const http = require('http');
const fullname = 'Seye Olofinyo';
const ID = 'HNG-02018';
const language = 'Javascript';
const email = 'seyeolofinyo@yahoo.com';

// const server = http.createServer((req, res) => {

//     res.status(200).json(`Hello World, this is ${fullname} with HNGi7 ID ${ID} using ${language} for stage 2 task. ${email}`)
// });

// server.listen(process.env.PORT || 8080);

console.log(`Hello World, this is ${fullname} with HNGi7 ID ${ID} using ${language} for stage 2 task. ${email}`)

