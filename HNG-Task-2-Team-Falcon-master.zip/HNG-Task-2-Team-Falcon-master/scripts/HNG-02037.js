const fullName = 'Badru Rahman Oluwadolapo';
const id = 'HNG-02037';
const language = 'Javascript';
const email = 'dolapobadru@gmail.com';

console.log(`Hello World, this is ${fullName} with HNGi7 ID ${id} using ${language} for stage 2 task. ${email}`);

// declared variables and used console log to print statement via string interpolation