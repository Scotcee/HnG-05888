name ="oluwafemi sopade"
ID = "HNG-02048"
Email= "icekidz1997@gmail.com"



print(f"Hello World, this is {name} with HNGi7 ID {ID} using python for stage 2 task. {Email}", flush = True)

