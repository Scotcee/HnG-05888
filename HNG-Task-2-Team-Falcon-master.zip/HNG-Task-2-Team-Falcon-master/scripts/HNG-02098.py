print ("Hello World, this is Israel Akinpelu with HNGi7 ID HNG-02098 using Python for stage 2 task")
