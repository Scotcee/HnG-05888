var fullName = "Olalere Abdulazeez";

var ID = "HND-02121";

var language = "Javascript";

var Email= "olalereazeez11@gmail.com";

var myString = `Hello World, this is ${fullName} with HNGi7 ID ${ID} using ${language} for stage 2 task. ${Email}`;
console.log(myString);
