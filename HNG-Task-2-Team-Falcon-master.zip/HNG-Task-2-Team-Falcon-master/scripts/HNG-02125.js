        var name = "Shotolu Paul"
        var hngid = "HNG-02125"
        var lang = "Javascript"
        var mail= "paulshotolu@gmail.com"

		function paulfunc() {
		   return ('Hello World, this is '+ name +' with HNGi7 ID '+ hngid +' using '+ lang +' for stage 2 task. '+ mail +'');
		}
		console.log(paulfunc());
