
    var name = "Shotolu Paul"
        var hngid = "HNG-02125"
        var lang = "javascript"
        var email= "paulshotolu@gmail.com"

		function paulfunc() {
		   return ('Hello World, this '+ name +' with HNGi7 ID '+ hngid +' using '+ lang +' for stage 2 task. '+ email +'');
		}
		console.log(paulfunc());
