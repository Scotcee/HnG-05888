(() => {
	const fullName = 'Taiwo Ogunola';
	const email = 'uniqueomokenny@gmail.com';
	const myId = 'HNG-02175';
	const lang = 'JavaScript';

	const returnStr = `Hello World, this is ${fullName} with HNGi7 ID ${myId} using ${lang} for stage 2 task. ${email}`;

	console.log(returnStr);
})();
