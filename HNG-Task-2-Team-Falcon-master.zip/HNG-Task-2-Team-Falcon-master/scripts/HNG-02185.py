def hng_x():
  print("Hello World, this is Henry Ihenacho with HNGi7 ID HNG-04817 and email chukwuemeka.ihenacho@stu.cu.edu.ng using Python for stage 2 task."
  
  
def main():
  hng_x()
  
main()
  
  
