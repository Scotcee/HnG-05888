def task2():
    my_name = "Iniobong Afahakan"
    my_id = "HNG-02219"
    language = "Python"
    my_email = "iniobong.afahakan@gmail.com"

    print(f"Hello World, this is {my_name} with HNGi7 ID {my_id} using {language} for stage 2 task. {my_email}", flush=True)


task2()
