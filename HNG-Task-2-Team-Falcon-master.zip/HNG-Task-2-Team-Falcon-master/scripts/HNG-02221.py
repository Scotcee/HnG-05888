name = 'Falae Temitope'
id = 'HNG-02221'
language = 'Python'
email = 'leutoby@gmail.com'

print (f"Hello World, this is {name} with HNGi7 ID {id} using {language} for stage 2 task. {email}", flush=True)