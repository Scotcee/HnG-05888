newbie = "Hello World, this is Nwachukwu Obed Onyekachi with HNGi7 ID HNG-02326 using python for stage 2 task. nwagodobed24@gmail.com"
print(newbie, flush=True)
