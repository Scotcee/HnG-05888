Just created a concept that I hope would bring back the desired result.
