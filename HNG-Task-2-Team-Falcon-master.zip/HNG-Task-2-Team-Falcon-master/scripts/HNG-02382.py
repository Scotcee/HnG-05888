### HNGi7 Internship Task 2 ###

### Write a script file using any language of choice to show your name, HNG ID, language used and email.

### variables name, Id, lang and email are declared below

name = "Osigbemhe Omhoape Leo"
Id = "HNG-02382"
lang = "Python"
email = "leobary86@yahoo.com"

### This prints out the reuired output

#print ('"Hello World, this is ' + name + ' with HNGi7 ID ' + Id + ' using ' + lang + ' for stage 2 task." ' + email )

print ('Hello World, this is', name, 'with HNGi7 ID', Id, 'using', lang,  'for stage 2 task.', email)

### Whoa!!! either of the two works, but i would go with the second because it took me back and forth, smiles!!!
