first = "Osahon"
last = "Ukpebor"
HNG_id = "HNG-02391"
language = "Python"
email_address = "ukpeborosahon@yahoo.com"

print(f"Hello World, this is {first} {last} with HNGi7 ID {HNG_id} and email {email_address} using {language} for stage 2 task.")