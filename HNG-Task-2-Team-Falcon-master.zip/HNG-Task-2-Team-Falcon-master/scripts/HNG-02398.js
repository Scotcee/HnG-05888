const email = "gracetemitope14@gmail.com"
const greetings = "Hello World,"
const intro = "this is Temitope Grace with HNGi7 ID HNG-02398 using JavaScript for stage 2 task"
console.log(greetings + " " + intro);
