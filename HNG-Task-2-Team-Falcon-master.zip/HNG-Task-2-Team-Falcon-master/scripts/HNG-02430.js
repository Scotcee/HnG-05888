const name = "Onyegbu Ifedili";
const email = "onyegbuifedili@gmail.com";
const HNGid = "HNG-02430";
const lang = "Javascript"

let outputString = () => {
  let str = `Hello World, this is ${name} with HNGi7 ID ${HNGid} using ${lang} for stage 2 task. ${email}`
  console.log(str)
}

outputString()
