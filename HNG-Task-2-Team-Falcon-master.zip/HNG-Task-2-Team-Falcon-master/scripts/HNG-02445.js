var fullName= "Ayodele PraiseGod"
var email = "eremapraiz@gmail.com"
var languageUsed= "JavaScript"
var hngId= "HNG-02445"
var myScript ="Hello World, this is " + fullName + " with HNGi7 ID " + hngId + " using " + languageUsed + " for stage 2 task. " + email
console.log(myScript)
