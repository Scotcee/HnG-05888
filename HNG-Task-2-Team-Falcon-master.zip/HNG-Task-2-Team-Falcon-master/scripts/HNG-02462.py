# HNG Task 2
print("Hello World, this is Ibitayo Ishalaiye with HNGi7 ID HNG-02462 using python for stage 2 task. ibitayo.ishalaiye@yahoo.com")
