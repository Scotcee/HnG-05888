var fullname = 'Bankole Ahmed';
var id = 'HNG-02467';
var language = 'JavaScript';
var email = 'kidrolex19@gmail.com';

console.log('Hello world, this is ' + fullname + ' with HNGi7 ID ' + id + ' using ' + language + ' for stage 2 task' )

