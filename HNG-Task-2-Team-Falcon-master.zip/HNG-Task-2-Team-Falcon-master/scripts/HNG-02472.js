let intern = {
    "firstName": "Ridwan",
    "lastName": "Osho",
    "ID": "HNG-02472",
    "favLanguage": "Javascript",
    "email": "ridwanosho@outlook.com"
};

console.log(`Hello World, this is ${intern.firstName} ${intern.lastName} with HNGi7 ID ${intern.ID} using ${intern.favLanguage} for stage 2 task. ${intern.email}`);
