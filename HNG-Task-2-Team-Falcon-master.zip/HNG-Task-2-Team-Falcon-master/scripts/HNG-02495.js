const full_name = "Teleayo Oyekunle";
const hng_id = "HNG-02495";
const lang = "javascript";
const email = "randomlyinspirational@gmail.com";

let output = `Hello World, this is ${full_name} with HNGi7 ID ${hng_id} using ${lang} for stage 2 task. ${email}`;
console.log(output);
