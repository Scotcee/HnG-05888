cmd=True
def user(cmd):
	comment='Program Closed thanks for checking\nPlease grade me well!'
	if cmd :
		print('Hello world')
		name='Samuel Jonathan'
		id='02502'
		language='Python'
		email='omohsam81@gmail.com'
		print(name,id,language,email)
		print(comment)	

		
user(cmd)

