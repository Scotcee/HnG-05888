full_name = 'Abdulmalik Giwa'
HNG_ID = 'HNG-02524'
language = 'Python'
email = 'giwa.omotola@gmail.com'
print('Hello World, this is {} with HNGi7 ID {} using {} for stage 2 task. {}'.format(full_name,HNG_ID,language,email))
