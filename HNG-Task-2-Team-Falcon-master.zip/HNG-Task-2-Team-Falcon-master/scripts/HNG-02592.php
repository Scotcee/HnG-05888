<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stage 2 Assignment</title>
</head>

<body>

    <?php


    // variable declaration and Initializing

    $names = "Olatunji Omogbemile";
    $id = "HNG-02592";
    $email = "o.omogbemile@gmail.com";
    $language = "php";
    ?>
    <div>
        <?php //call variables into output text
        ?>
        <h1> <?php echo "Hello World! <br> My name is " . $names . " with " . $id . " using " . $language . " for stage 2 task. <br> This is my email: " . $email . "";
                ?> </h1>
    </div>



</body>

</html>