<?php
echo 'Hello World, this is Joseph Ero with HNGi7 ID HNG-02637 using PHP for stage 2 task. erojoseph94@gmail.com';
?>
