const mFullName = "Oluwaseyifunmi Ipaye";
const mHngId = "HNG-02647";
const mLanguage = "JavaScript";
const mEmail = "seyipaye@gmail.com";

console.log(`Hello World, this is ${mFullName} with HNGi7 ID ${mHngId} using ${mLanguage} for stage 2 task. ${mEmail}`)
