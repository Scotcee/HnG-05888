
const name = "Luwafemi Alade";
const id = "HNG-02667";
const language = "javascript";
const email = "aladefemi1@gmail.com";
const output = `Hello World, this is ${name} with HNGi7 ID ${id} using ${language} for stage 2 task. ${email} `;
console.log(output);
