
<?php
echo "Hello World, this is Daniel Kweka with HNGi7 ID HNG-02715 using PHP for stage 2 task danielkweka97@gmail.com";
?>
