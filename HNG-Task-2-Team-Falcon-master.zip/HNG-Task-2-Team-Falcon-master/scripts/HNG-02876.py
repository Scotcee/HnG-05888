Name = 'Akinwande Komolafe'
HNGi7ID = 'HNG-02876'
PreferredLanguage = 'Python'
Stage = '2'
email = 'akinwandekomolafe@gmail.com'

print(f"Hello World, this is {Name} with HNGi7 ID {HNGi7ID} using {PreferredLanguage} for stage {Stage} task. {email}", flush=True)
