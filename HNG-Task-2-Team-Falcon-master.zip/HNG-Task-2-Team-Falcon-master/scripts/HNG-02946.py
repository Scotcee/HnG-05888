print(“Hello World, this is Adebisi Ayomide with ID HNG-02946 and email adebisiayomide07@gmail.com using python for the stage 2 task”)
