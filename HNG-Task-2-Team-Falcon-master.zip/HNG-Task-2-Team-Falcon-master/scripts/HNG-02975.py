

name = 'Motolani Ajibola'
id = 'HNG-02975'
language = 'Python'
email = 'aveirahabeeb@gmail.com'
print("Hello World, this is " + name + " with HNGi7 ID " + id + " using " + language + " for stage 2 task. " + email)


