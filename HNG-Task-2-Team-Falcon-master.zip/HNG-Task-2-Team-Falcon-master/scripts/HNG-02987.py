fullname = "Chihurumnanya Nwanevu"
ID = "HNG-02987"
language = "Python"
email = "nwanevunkem.chihurumnanya@gmail.com"

print (f"Hello World, this is {fullname} with HNGi7 ID {ID} using {language} for stage 2 task. {email}")
