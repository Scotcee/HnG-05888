

// declaration of varibles =====================================================================================================================================
let myName = "Anumudu Chukwuebuka Victor";
let myId = "HNG-02993";
let myLanguage = "Javascript";
let myEmail = "anumuduchukwuebuka@gmail.com";
// END of declaration of varibles =====================================================================================================================================


// Function to INTRODUCE ME =====================================================================================================================================
const introduceMe = () => {
    console.log(`Hello World, this is ${myName} with HNGi7 ID ${myId} using ${myLanguage} for stage 2 task. ${myEmail}`)
}
//END of Function to INTRODUCE ME =====================================================================================================================================


introduceMe()