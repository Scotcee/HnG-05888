console.log("Hello World, this is Ayodele Salimonu, with id HNG-03058, using javascript for step 2 task. ayodele951@gmail.com");
