console.log("Hello World, this is Ezeka Emmanuel Chukwuka with HNGi7 ID HNG-03111 and email eec.studies@gmail.com using JavaScript for stage 2 task")
