void main() {
  
  String name = "Tayo Olakunle  ";
  String hngId = "HNG-03131  ";
  String language ="Dart  ";
  String email ="tayoolakunle77@gmail.com";

  print("Hello World This is \n" + name +"with \n"+ hngId + "Using \n" +language + "for stage 2 task");
}
