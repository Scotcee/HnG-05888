<?php
$adtrex = "Hello World, this is Adekunte Tolulope with HNGi7 ID HNG-03141 using PHP for stage 2 task. toluadekunte@gmail.com";
echo $adtrex;
?>