print("Hello World, this is Isaac Kamula with HNGi7 ID HNG-03819 using Python language for stage 2 task.")
