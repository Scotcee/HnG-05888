full_name = "Popoola Boluwatife"
hng_id = "HNG-03211"
language = "Python"
email = "olaoyejnr@gmail.com"

print(f'Hello World, this is {full_name} with HNGi7 ID {hng_id} using {language} for stage 2 task. \n {email}')
