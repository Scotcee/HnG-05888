const fullName = 'Chijioke Nwagwu';
const ID = 'HNG-03249';
const language = 'JavaScript';
const email = 'wyhzest@gmail.com';

console.log(`Hello World, this is ${fullName} with HNGi7 ID ${ID} using ${language} for stage 2 task. ${email}`);
