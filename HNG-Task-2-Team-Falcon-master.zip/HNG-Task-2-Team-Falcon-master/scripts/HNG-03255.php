<?php 
$firstName = "Mamus";
$lastName = "Eferha";
$id = "HNG-03255";
$lang = "PHP";
$email = "eferhamamus@gmail.com";

echo "Hello World, this is " .$firstName ." " .$lastName . " with HNGi7 ID " .$id . " using " .$lang ." for stage 2 task". ". " . $email;
?>