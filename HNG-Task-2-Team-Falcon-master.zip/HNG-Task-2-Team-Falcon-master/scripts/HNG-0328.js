console.log("Hello World, this is abdul jalil zakaria with HNGi7 ID 03280 using javascript for stage 2 task. email:abduljalilzakaria1@gmail.com");
