# variables containing my submission data
full_name = "Chandra Sekhar Mullu"
internship_id = "HNG-03304"
language_used = "Python"

# print the in the required format to stdout
print(
    f"Hello World, this is {full_name} with HNGi7 ID {internship_id} using {language_used} for stage 2 task")
