def introduction():
    name = "Abdulateef Gafar"
    ID = "HNG-03315"
    language = "Python"
    email = "abdulateef.gafar@gmail.com"
    my_intro = "Hello World, this is " + name + " with HNGi7 ID " + ID + " using " + language + " for stage 2 task. " + email
    return my_intro

print(introduction())