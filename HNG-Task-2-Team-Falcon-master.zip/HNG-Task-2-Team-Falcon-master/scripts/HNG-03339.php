<?php

$full_name = "Awadh Salim Nassor";
$ID = "HNG-03339";
$language = "PHP";
$email = "awadhsalim470@gmail.com";

$script = "Hello World, this is ".$full_name." with HNGi7 ID ".$ID." using ".$language." for stage 2 task ".$email;

echo $script;


?>
