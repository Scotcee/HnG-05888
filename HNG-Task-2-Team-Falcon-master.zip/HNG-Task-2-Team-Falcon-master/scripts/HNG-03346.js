
console.log("Hello World, this is Yehualashet Abebe with HNGi7 ID HNG-03346 using Javascript for stage 2 task. yehualashetab@gmail.com");
