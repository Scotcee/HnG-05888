var message = "Hello world,";
var name = "Megha Sharma";
var id = "HNG-03355";
var emailid = "meghasharma2822000@gmail.com";
console.log(`${message} this is ${name} with HNGi7 ID ${id} using Javascript for stage 2 task. ${emailid}`);
