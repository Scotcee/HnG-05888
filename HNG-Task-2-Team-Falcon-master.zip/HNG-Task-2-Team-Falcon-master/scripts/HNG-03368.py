fullname="Enweazu Daniel Chukwuebuka"
internshipID= "HNG-03368"
language="Python"
email="enweazu.daniel@gmail.com"
print("Hello World, this is {} with HNGi7 ID {} using {} for stage 2 task {}" .format(fullname,internshipID,language,email))
