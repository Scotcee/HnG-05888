let name ='Dauda Oziegbe Dauda';
let id = 'HNG-03385';
let language = 'javascript';

console.log(`Hello World,this is ${name} with HNGi7 ID ${id} using ${language} for stage 2 task");
