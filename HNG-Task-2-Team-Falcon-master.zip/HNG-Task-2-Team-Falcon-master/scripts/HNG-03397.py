print ("Hello World, this is Oluwatooni Adebiyi with HNGi7 ID HNG-03397 using Python for stage 2 task")
