<?php
  $fname=  "Okeke Victor Emeka";
  $id= "HNG-03406";
  $lang=  "PHP";
  $email=  "Okekevicktur@gmail.com";
  
  echo "Hello World, this is  $fname with HNGi7 ID  $id using $lang for stage 2 task. $email";
?>
