const name = 'AKINDELE MUHYIDEEN'
const ID = 'HNG-03451'
const email = 'akindelemuhyideen@gmail.com'

console.log(`Hello World, this is ${name} with ID ${ID} using javascript for the stage 2 task. ${email} `)
