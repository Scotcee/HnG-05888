let name = "Jonathan Enudeme";
let id = "HNG-03496";
let language = "javascript";
let email = "twoejoe5@gmail.com";
let task = `Hello World, this is ${name} with HNGi7 ID ${id} using ${language} for stage 2 task. ${email} `;
console.log(task);
