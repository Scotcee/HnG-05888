<?php  
$firstName = "Abdullahi";
$lastName = "Abdulazeez";
$hng_id = "HNG-03507";
$lang = "PHP";
$email = "abdulazeezabdullahi57@gmail.com";
echo "Hello World, this is $firstName $lastName with HNGi7 ID $hng_id using $lang for stage 2 task. $email";
?>
