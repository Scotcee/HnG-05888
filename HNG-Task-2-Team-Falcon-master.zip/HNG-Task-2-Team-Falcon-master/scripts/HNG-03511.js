

console.log("Hello World, this is Josh Anderson, with HNGi7 iD HNG-03511 using javascript for stage 2 task. joshiandersonk69@gmail.com");