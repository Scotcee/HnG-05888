<?php 
    echo '<p>Hello World! This is <strong>Jeremiah Favour Iromaka</strong> with HNGi7 ID <strong>HNG-03555</strong> using <strong>PHP</strong> for stage 2 task. <strong>Jeremiahiro@gmail.com</strong></p>'; 
?> 
