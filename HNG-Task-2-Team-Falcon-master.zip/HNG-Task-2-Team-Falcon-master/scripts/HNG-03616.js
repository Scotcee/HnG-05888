const Name = "Anthony Nwobodo";
const HNGID = "HNG-03616";
const Language = "Javascript";
const Email = "anthonynwobodo7@gmail.com";
////////////////////////////////////////////////////////////////////////////////
const intro = (Name, HNGID) => {
  return `Hello World, this is ${Name} with HNGi7 ID ${HNGID} using ${Language} for stage 2 task. ${Email}`;
};

///////////////////////////////////////////////////////////////////////////
console.log(intro(Name, HNGID));
