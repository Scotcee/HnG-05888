var name = "Akande Ayodeji";
var id = "HNG-03629";
var email = "ayodejiakande2107@gmail.com";
console.log("Hello World, this is" + " " + name + " " + "with HNGi7 ID" + " " + id +  " " + "using Javascript for stage 2 task");