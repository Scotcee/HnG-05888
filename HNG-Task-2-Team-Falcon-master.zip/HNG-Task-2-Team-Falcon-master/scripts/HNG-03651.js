const me = {
  "firstName": "Oluwatobi",
  "lastName": "Odekunle",
  "email": "ooluwatobialao@gmail.com",
  "language": "JavaScript",
  "HNG_ID": "HNG-03651"
};

const {firstName,lastName,email,language,HNG_ID} = me;

console.log(`Hello World, this is ${firstName} ${lastName} with HNGi7 ID ${HNG_ID} using ${language} for stage 2 task. ${email}`);
