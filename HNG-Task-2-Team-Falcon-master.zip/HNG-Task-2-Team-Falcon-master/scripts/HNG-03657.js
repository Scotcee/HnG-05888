
const info = () => {
    const full_name = `Samuel Johnson`;
    const hng_id = `HNG-03657`;
    const language = `JavaScript`;
    const email = `samuelj4real17@gmail.com`
    const result = `Hello World, this is ${full_name} with HNGi7 ID ${hng_id} using ${language} for stage 2 task. ${email} `;
    console.log(result);
}

info();
    
    
    
    
    
