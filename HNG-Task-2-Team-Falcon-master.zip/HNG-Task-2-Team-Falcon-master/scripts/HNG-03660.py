def task2_team_falcon(ID,name,lang,email):
    print("Hello World, this is {0} with HNGi7 ID {1} using {2} for stage 2 task. {3}".format(name,ID,lang,email))

ID= 'HNG-03660'
name= 'Mayank Kumar'
lang= 'Pyhton'
email= 'mayank9404@gmail.com'

task2_team_falcon(ID,name,lang,email)
