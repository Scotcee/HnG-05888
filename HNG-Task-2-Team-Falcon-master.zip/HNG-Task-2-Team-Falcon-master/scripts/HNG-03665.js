
/*************************************************
 *************************************************
* This is a task for HNGi-7
* Author Name: Isaiah Abiodun with ID: HNG-03665
* ************************************************
* ****************************************************
*/


const task2 = () => "Hello World, this is Isaiah Abiodun with HNGi7 ID HNG-03665 using JavaScript for stage 2 task. isaiah.abiodun@outlook.com."
task2();


console.log(task2());

