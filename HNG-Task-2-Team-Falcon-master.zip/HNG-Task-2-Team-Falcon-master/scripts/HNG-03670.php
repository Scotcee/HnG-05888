<?php
echo "Hello world, this is Johnson Francis with HNGi7 ID HNG-03670 using php for stage 2 task. Johnsonkayode01@gmail.com";
?>
