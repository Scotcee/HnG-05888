
  const name = "Moses Obike";
  const id ="HNG-O3841";
  const lang ="Javascript";

  const email= "mosesobike@gmail.com";
   console.log(`Hello World, this is ${name} with HNGi7 ID ${id} using ${lang} for stage 2 task. ${email}`);
