let string = "Hello World, this is Ebrima G. Jallow  with HNGi7 ID HNG-03843 using JavaScript for stage 2 task. egjallow10@gmail.com";
function secondTest(name){
    return name;

};

secondTest(string);