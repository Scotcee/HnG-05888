const userName = "Basit Ajao";
const hngId = "HNG-03917";
const lang = "javascript";
const email = "Basitajao96@gmail.com"

function task () {
    return `Hello World,this is ${userName} with HNGi7 ID ${hngId} using ${lang} for stage 2 task`  
}
console.log(task()) 