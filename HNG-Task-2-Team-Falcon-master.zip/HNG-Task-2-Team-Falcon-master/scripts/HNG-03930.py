name = "Siddhi Jha"
id = "HNG-03930"
language = "python"
email = "siddhijha023@gmail.com"
print("Hello World, this is",name,"with HNGi7 ID",id,"using",language,"for stage 2 task.",email)
