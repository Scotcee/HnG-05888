print("Hello world, this is Alahira Jeffrey Calvin with HNGi7 ID  HNG-03937 using python for stage 2 task")
