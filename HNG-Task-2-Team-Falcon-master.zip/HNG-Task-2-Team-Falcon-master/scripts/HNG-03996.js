


const messageOne ='Hello World,';
const myDetails ='this is Satih Hilda Adjekawe with'; 
const regNo   ='HNGi7 ID HNG-03996';
const language='using Javascript';
const messageTwo ='for stage 2 task';
const myEmail ='hildasatih@gmail.com';

console.log(`${messageOne} ${myDetails} ${regNo} ${language} ${messageTwo} ${myEmail}`);

