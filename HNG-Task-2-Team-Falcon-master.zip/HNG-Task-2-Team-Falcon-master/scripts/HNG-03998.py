def greetings(name, id, language, email):
    print(f"Hello World, this is {name} with HNGi7 ID {id} using {language} for stage 2 task and my email is {email}.")

greetings("Asala Collins Oluwaseun", "03998", "python", "asalacollins04@gmail.com")