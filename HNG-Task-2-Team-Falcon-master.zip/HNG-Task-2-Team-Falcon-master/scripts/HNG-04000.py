fullname = "Omikunle Okiki Joshua"
slack_id = "HNG-04000"
language = "python"
email = "okikiomikunle@gmail.com"
print("Hello World, this is", fullname, "with HNGi7 ID",slack_id,"and email",email ,"using", language, "for stage 2")
