
console.log ("Hello World, this is Tolu Lawson with HNGi7 ID HNG-04084 using JavaScript for stage 2 task. lawsontolu1@gmail.com");

