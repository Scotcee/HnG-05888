var marvelous = "Hello World, this is Abe Marvellous with HNGi7 ID 4087 using Javascript for stage 2 task.abemarvelouskam@gmail.com";                        
console.log(marvelous);
