const fullName = "Favour Nifemi F";
const id = 04149;
const language = "Javascript";
const email = "shoppernife@gmail.com";
 
console.log(`Hello world, this is ${fullName} with HNGi7 ID ${id} using ${language} for stage 2 task ${email}.`);
