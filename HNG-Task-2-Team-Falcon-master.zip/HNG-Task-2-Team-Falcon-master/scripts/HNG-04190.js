let name = "Wokomaty Chibuzor", id = "HNG-04190", email = "jwokomaty@gmail.com", language = "NodeJS";

const intern = () => `Hello World, this is ${name} with HNGi7 ID ${id} using ${language} for stage 2 task. ${email}`;

console.log(intern());