'use strict';
const introduceMyself = (fullName, id, preferredLang, email) => {
  console.log(
    `Hello World, this is ${fullName} with HNGi7 ID ${id} using ${preferredLang} for stage 2 task.${email}`
  );
};

introduceMyself('Ayomide', '04256', 'javascript', 'wilsonace87@gmail.com');
