function mySecondTask (name, id, language, email) {
let statement = `Hello World, this is ${name} with HNGi7 ID ${id} using ${language} for stage 2 task. ${email}`;
console.log(statement);
} 

mySecondTask ('Ummul-Khair Zurak', 'HNG-04258', 'JavaScript', 'zurakummu@gmail.com')
