<?php 

$name = 'Prince Isaac ';
$id = 'HNG-04305';
$language = 'PHP';
$email = 'isaacprince002@gmail.com';

echo "Hello World, this is {$name} with HNGi7 ID {$id} using {$language}, email: {$email} for stage 2 task";

?>