console.log("Hello World, this is Ugoh Uchenna with HNGi7 ID HNG-04351 using JavaScript for stage 2 task. ucugooh@gmail.com");
