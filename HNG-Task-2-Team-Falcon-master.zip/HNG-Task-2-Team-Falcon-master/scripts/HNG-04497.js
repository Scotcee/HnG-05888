var id = 04479, name = "Uyanna Michael Ahamefula", lang = "JavaScript";
var message = "Hello world, this is "+ name +" with HNGi7 ID "+ id +" using "+ lang +" for stage 2. "+ 
" crackmastermike@gmail.com.";
console.log(message);
