const myEmail = 'jabichris@gmail.com'
const myName = 'JABIRO Christian';
const myId = 'HNG-04519';
const myLanguage = 'Javascript';

const myScript = () => console.log('Hello World, this is '+ myName +' with HNGi7 ID '+ myId + 'using '+ myLanguage +' for stage 2 task. ' + myEmail);

myScript();

