email = "gbolahanoduyemi1@gmail.com"
print("Hello World, this is Gbolahan Oduyemi with HNGi7 ID HNG-04552 using Python for stage 2 task. Email:"+email)
