email = "ayomilotunde02@gmail.com"
print("Hello World, this is Adeoye Ayomide with HNGi7 ID HNG-04569 using Python for stage 2 task. Email:"+email)
