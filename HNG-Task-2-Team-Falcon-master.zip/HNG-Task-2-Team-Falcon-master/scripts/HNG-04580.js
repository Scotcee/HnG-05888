var name = 'fadoju oluwaseyi anuoluwapo';
var id = 'HNG-04580';
var email = 'fadojuoluwaseyi@gmail.com';
var language ='javascript';
function credentials(){
       let details = 'Hello World, this is ' + name + ' with HNGi7 ID ' + id + ' using ' + language + ' for stage 2 task. '  + email ;
       return console.log(details )
}
credentials  ()
