var myFullName = "OJO BABAJIDE OLAYINKA";

var myHngId = "HNG-04603";

var myLang = "JAVASCRIPT";

var myEmailAdd = "ojobabajide629@gmail.com";


console.log("Hello World, this is ${myFullName} with HNGi7 ID ${myHngId} using ${myLang} for stage 2 task. ${myEmailAdd}");
