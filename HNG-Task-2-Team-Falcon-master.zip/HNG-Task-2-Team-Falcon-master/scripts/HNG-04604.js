function homeWork(){
    let name = "Olamide Akodu";
    let id = "HNG-04604";
    let email = "akodu.olamide@gmail.com";
    let language = "javascript";
    console.log("Hello World, this is " + name + " with HNGi7 ID " + id + " using " + language + " for stage 2 task. " + email);
}
homeWork();
