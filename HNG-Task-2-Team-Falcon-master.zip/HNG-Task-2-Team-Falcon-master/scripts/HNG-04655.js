const myFunction = () => {

    let fullname = 'Babatunde Damilare';
    let hngId = 'HNG-04655';
    let devLang = 'Javascript';
    let email  = 'bdamilare3@gmail.com';

    console.log(`Hello World, this is ${fullname} with HNGi7 ID ${hngId} using ${devLang} for stage 2 task. ${email}`);
};

myFunction();
