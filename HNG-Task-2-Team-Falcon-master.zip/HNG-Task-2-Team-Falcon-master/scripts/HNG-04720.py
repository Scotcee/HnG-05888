name = 'Victor Chidubem Mazeli'
hng_id = '04720'
language = 'python'
email = 'victor.vic.mazeli@gmail.com'

print('Hello World, this {0} with HNGi7 ID {1} using {2} for stage 2 task. {3}'.format(name, hng_id, language, email))