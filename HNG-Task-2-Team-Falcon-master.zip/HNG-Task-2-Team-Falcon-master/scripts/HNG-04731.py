a = "'Hello World, this is JOKOTAGBA OPEMIPO ADESEGUN with HNGi7 ID HNG-04731 using PYTHON for stage 2 task'. opemipojokotagba@gmail.com" 
  print(a)
