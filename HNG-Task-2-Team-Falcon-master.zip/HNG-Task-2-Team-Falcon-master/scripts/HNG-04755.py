def hng_details():

    fullname = "Andrew Osabuede Gabriel"
    id = "HNG-04755"
    language = "Python"
    email = "buedgabby@gmail.com"

    print("Hello World, this is " +fullname+" with HNGi7 ID "+id+" using "+language+" for stage 2 task. "+email,flush=True)

hng_details()