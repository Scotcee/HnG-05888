console.log("Hello World, this is Najib Muhammad Kado with HNGi7 ID HNG-04869 using javascript for stage 2 task najibkado@gmail.com");

