'''

Developer: Elpis

Date Created: 3rd of June, 2020

'''

#Variable assigment section

email = 'elpis405@gmail.com'

fullname = 'Gbolade Festus'

hng_id = 'HNG-04887'

language = 'Python'



#print section

task = f'Hello World, this is {fullname} with HNGi7 ID {hng_id} using {language} for stage 2 task'

print(task)

