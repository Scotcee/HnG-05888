full_name = "Onyepunuka Ugochukwu"
hngid = "HNG-04941"
language = "python"
my_email = "uonyepunuka@gmail.com"
print("Hello World, this is %s with HNGi7 ID %s using %s for stage 2 task. %s"%(full_name, hngid, language, my_email))
