<?php
/*****************************************************************************************************
FUNCTION TO RETURN STRING PASSED
*****************************************************************************************************/
function echoString($string_to_be_returned){
    echo $string_to_be_returned;
}

echoString("Hello World, this is Olatunji Olayemi with HNGi7 ID HNG-05017 using PHP for stage 2 task. olayemi289@gmail.com");
?>
