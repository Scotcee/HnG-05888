full_name = 'Nwigwe Ifeanyi Michael'
hng_id = 'HNG-05019'
language = 'Python'
email = 'rubzyg@gmail.com'
msg = f'Hello World, this is {full_name} with HNGi7 id {hng_id} using {language} for stage 2 task. {email}'

print(msg)