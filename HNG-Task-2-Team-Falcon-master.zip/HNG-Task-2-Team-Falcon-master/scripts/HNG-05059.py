def user(user_input):
	return user_input
print(user("Hello World, this is Emmanuel Fasanya with HNGi7 ID HNG-05059 using Python for stage 2 task. fasanyapluse@gmail.com"))