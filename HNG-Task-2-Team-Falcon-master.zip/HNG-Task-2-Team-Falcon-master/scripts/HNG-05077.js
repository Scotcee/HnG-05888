const name = "Jezeh Priesten";
const email = "jepriesten@gmail.com";
const HNGi7_ID = "HNG-05077";
const language = "javascript";

function detailsPrintOut() {
  console.log(
    `Hello World, this is ${name} with HNGi7 ID ${HNGi7_ID} using ${language} for stage 2 task. ${email}`
  );
}

detailsPrintOut();
