var fullName = "Christian Chukwu";
var ID = "HNG-05107";
var language = "JavaScript"
var email = "christianchukwu84@gmail.com"

console.log(`Hello World, this is ${fullName} with HNGi7 ID ${ID} using ${language} for stage 2 task. ${email}`);
