#!/usr/bin/env python
# coding: utf-8

# In[1]:


name = 'Emmanuel Siaw Darko'
iiid = 'HNG-05109'
language = 'Python'
email = 'immanuelsiawdarko@gmail.com'
print("Hello World, this is {} with HNGi7 ID {} using {} for stage 2 task. {}".format(name, iiid, language, email))


# In[ ]:




