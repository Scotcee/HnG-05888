let id = "HNG-05114"
let fullName = "Udofa Daniel"
let language = "JavaScript"
let email ="danieludofa452@gmail.com"

let text = "Hello World,  this is  "+fullName+" with HNGi7 ID "+id+ " using "+language+" for stage 2 task.  " +email+"";

console.log(text);
