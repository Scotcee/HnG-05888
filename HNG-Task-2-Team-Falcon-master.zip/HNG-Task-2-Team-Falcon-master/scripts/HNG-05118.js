const full_name = "Popoola Ibukunoluwa Gbolade"
const ID = "HNG-05118"
const language = "Javascript"

function task_2() {
	console.log(`Hello World, this is ${full_name} with HNGi7 ID ${ID} using ${language} for stage 2 task. ibukunoluwa.g.popoola@gmail.com`)
} 

task_2();
