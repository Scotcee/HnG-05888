Name = "Temitope Ilesanmi"
Id = "HNG-05123"
emailId = "ilesanmiisaac@gmail.com"
language = "Python"
 
def hello():
  return "Hello World, this is " + Name + " with HNGi7 ID " + Id + " using " + language + " for stage 2 task. " + emailId

print(hello(), flush = True)
