Function myTask() { 
   let taskTwo = 'Hello World, this is Chinyerem Emmanuel with HNGi7 HNG-05230 using JavaScript for stage 2 task. Kelvinesthy@gmail.com'
   return taskTwo
 }
console.log(myTask)
