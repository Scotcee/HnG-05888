print('Hello World, this is Douglas Kojo Gidimadjor with HNGi7 ID HNG-05236 using python for stage 2 task. douglasgidi1@gmail.com')
