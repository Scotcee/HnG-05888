
let greetings = 'Hello World';
var first_Name = 'Wisdom';
let last_Name = 'Ekpotu';
var fullName = `${first_Name + ' ' + last_Name} `;
let id = 'HNG-05259';
var E_mail = 'Whizfidel@gmail.com';
var Language = 'javascript';

console.log(
  `${greetings}, this is ${fullName} with HNGi7 ID ${id} using ${Language} for stage 2 task. ${E_mail}. `
);


