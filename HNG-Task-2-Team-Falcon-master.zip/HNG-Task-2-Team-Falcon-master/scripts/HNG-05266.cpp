#include <iostream>
using namespace std;

int main() {
    string fullName = "Collins Amabuo " ;
    string id = "05266 ";
    string language = "C++ " ;
    string email = "collinsamabuo@gmail.com " ;
    
    cout << "Hello World, this is " << fullName << "with HNGi7 ID " << id << "using " << language << "for stage 2 task. " << email << endl;
}
