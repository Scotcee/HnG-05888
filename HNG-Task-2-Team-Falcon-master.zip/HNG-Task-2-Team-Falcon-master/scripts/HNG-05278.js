let myName ="Emmanuel Kel Obi"
 let myId = "HNG-05278"
 let myEmail = "emmanuelobika5@gmail.com"
 let myData = "Hello World, this is" + myName + " with  HNGi7 ID " + myId + " using javascript for stage 2 task." + myEmail+ ""

  console.log(myData);


