full_name = 'Fasuba Daniel'
hng_id = '05315'
string = f"Hello world, this is {full_name} with HNGi7 ID HNG-{hng_id} using python for stage 2 task "

print(string)
