<?php
$FirstName = "Uzosike";
$LastName = "Adaku";
$HNGID = "HNG-05326";
$Language = "PHP";
$Email = "uzadaku96@gmail.com";
echo "Hello World, this is $FirstName $LastName with HNGi7 ID $HNGID using $Language for stage 2 task. $Email";