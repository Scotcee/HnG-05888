const name = 'Amasa Abubakar'
const id = '[HNG-05336]'
const lang = 'javascript'
const e = 'aremu14.amasa@hotmail.com'

console.log('Hello World,' + ' this is ' + name + ' with ' + 'HNGi7 ID ' + id + ' using ' + lang + ' for stage 2 task. ' + e)