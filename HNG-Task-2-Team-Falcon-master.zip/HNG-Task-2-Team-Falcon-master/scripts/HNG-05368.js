const name = "Daniel Agoziem"
const hngID = "HNG-05368"
const message = `Hello World, this is ${name} with HNGi7 ID ${hngID} using JavaScript for stage 2 task. stefanpongrz@gmail.com`


const printOut = () => {
    return message
}

console.log(printOut())