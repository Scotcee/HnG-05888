def hng_task2(Fullname, ID, P_Lang, E_Mail):

    Fullname = "CHUKWUNTA, Ernest Chukwuebuka"
    ID = "HNG-05375"
    P_Lang = "Python"
    E_Mail : "ernestchukwunta@yahoo.com"

    print("Hello World, this is {Fullname} with HNGi7 ID {ID} using {P_Lang} for stage 2 task. {E_Mail}", flush = True)
