<?php
$hng_fullname = "ELUGBADEBO ADEDOYIN";
$hng_id = "HNG-05441";
$hng_language = "PHP";
$hng_email = "eslintpurity@gmail.com";
echo "Hello World, this is $hng_fullname with HNGi7 ID $hng_id using $hng_language for stage 2 task. $hng_email";
?>

