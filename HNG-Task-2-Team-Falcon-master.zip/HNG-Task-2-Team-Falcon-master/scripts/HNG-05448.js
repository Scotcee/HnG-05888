const name = "Chia Gabriel";
const id = "HNG-05448";
const email = "gabrielsonchia@gmail.com";
const language = "JavaScript";

(function(name,HNGId,email,language){
    const output = `Hello World, this is ${name} with HNGi7 ID ${HNGId} using ${language} for stage 2 task. ${email}`
    console.log(output);
})(name,id,email,language);
