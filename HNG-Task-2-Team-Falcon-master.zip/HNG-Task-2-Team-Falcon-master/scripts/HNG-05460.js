hng05460 = () => {
    let userDetails = {
      fullName: 'Francis Franel Michael',
      id: 'HNG-05460',
      language: 'JavaScript',
      email: 'franel4u@gmail.com'
    };
    return `Hello World, this is ${userDetails.fullName} with HNGi7 ID ${userDetails.id} using ${userDetails.language} for stage 2 task. ${userDetails.email}`
  }
console.log(hng05460())