<?php
$value = "Hello World, this Emmanuel Bashorun with HNGi7 ID HNG-05476 using PHP for stage 2 task";
echo $value;
?>
