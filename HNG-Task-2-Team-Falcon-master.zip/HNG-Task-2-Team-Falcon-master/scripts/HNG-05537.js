const name = "Afolabi Timothy"
const HNG_id = "HNG-05537"
const language = "Javascript"
const email = "afolabi.timothy51@gmail.com"
const output = `Hello World, this is ${name} with HNGi7 ID ${HNG_id} using ${language} for stage 2 task. ${email}`

console.log(output) 