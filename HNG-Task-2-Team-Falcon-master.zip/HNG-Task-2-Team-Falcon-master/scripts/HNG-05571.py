Full_name = "Igwe Zion"
ID = "HNG-05571"
Language = "Python"
Email = "beingzheeta@gmail.com"

print("Hello World, this is " + Full_name + " with HNGi7 ID " + ID + " using " + Language + " for stage 2 task. " + Email)
