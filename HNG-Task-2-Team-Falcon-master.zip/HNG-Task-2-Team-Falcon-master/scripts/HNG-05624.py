details = "Hello World, this is Miracle Osigwe with HGNi7 ID HNG-05624 for stage 2 task"
print(details)
