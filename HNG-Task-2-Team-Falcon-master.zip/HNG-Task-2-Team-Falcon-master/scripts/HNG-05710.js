console.log("Hello World, this is Caleb Afoke Areeveso with HNGi7 ID HNG-05710 using javascript for stage 2 task.calebareeveso7@gmail.com")
