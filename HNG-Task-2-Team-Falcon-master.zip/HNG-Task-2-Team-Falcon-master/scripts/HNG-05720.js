const HNG_USER = {
  HNG_Name: "Samuel Abebayeu",
  HNG_Id: "HNG-05720",
  scriptLanguage: "javascript",
  email: "samuelabebayehu@gmail.com",
};
let message = `Hello World, this is ${HNG_USER.HNG_Name} with HNGi7 ID ${HNG_USER.HNG_Id} using ${HNG_USER.scriptLanguage} for stage 2 task. ${HNG_USER.email}`;

console.log(message);
