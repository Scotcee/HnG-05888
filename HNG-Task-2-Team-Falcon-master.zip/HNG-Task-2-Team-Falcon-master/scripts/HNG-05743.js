var myFullName = "Fasasi Olakunle";
var myHngId = "HNG-05743";
var myLanguage = "JavaScript";
var myEmail = "propertyvaluecss@gmail.com";

console.log(`Hello World, this is ${myFullName}, with HNGi7 ID ${myHngId}, using ${myLanguage} for stage 2 task. ${myEmail}.`)
