fullName = "Adedapo Anjorin"
Id = "HNG-05769"
language = "Python"
email = "femidpo3@gmail.com"

print("Hello World, this is " + fullName + " with HNGi7 ID " + Id + " using " + language + " for stage 2 task.")
