<?php
$name = 'Omisakin Oluwapelumi';
$id = 'HNG-05811';
$language = 'PHP';
$email = 'omisakin205@gmail.com';
echo "Hello World, this is {$name} with HNGi7 ID {$id} using {$language} for stage 2 task. {$email}";
?>
