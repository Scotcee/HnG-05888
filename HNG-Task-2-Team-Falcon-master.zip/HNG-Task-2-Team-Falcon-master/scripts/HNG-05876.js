function HNG_task02() 
{
    const FullName = 'Kanyinsola Olajide';
    var HNGi7ID = 'HNG-05876';
    const Language = "JavaScript";
    const Email = 'lloydd969@gmail.com';


    console.log('Hello World, this is ' + FullName +' with HNGi7 ID ' +HNGi7ID+ ' using '+Language+ ' for stage 2 task. Email = '+ Email);

  }
  HNG_task02();