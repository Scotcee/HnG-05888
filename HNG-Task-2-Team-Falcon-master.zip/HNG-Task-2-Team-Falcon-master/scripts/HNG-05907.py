print('Hello World, this is Animashaun Taofiq with HNGi7 ID HNG-05907 using Python for stage 2 task. animashauntaofiq@gmail.com')
