name = 'Gbadebo Oluwatobi'
id = 'HNG-05953'
language = 'Python'
email = 'gbadeboluwatobiloba@yahoo.com'

print(f'Hello World, this is {name} with HNGi7 id {id} using {language} for stage 2 task. {email}')

