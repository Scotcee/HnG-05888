let fullName = "Dogubo Mamuzo Joshua";
const ID = "HNG-06110";
const language = "javaScript";
const email = "emason.tech@gmail.com";
console.log (`Hello World, this is ${fullName} with HNGi7 ID ${ID} using ${language} for stage 2 task. ${email}`);
