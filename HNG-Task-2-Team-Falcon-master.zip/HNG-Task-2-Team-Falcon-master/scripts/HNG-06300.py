print("Hello World, this is Ndubuisi Christopher with HNGi7 ID HNG-06300 using python for stage 2 task. ndubuisichristopher@hotmail.com")
