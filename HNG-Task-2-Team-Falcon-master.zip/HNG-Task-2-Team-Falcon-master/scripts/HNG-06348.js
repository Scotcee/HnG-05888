console.log("Hello World, this is Ani Chidera James with HNGi7 ID HNG-06348 using Javascript for stage 2 task. achidera20@gmail.com")
