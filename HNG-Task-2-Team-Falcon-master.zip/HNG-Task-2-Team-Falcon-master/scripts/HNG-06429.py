fullname= "Isaac Adejuwon"
HNGi7ID= "U015FFYRNKS"
language= "python"
email= "isaacadejuwon27@gmail.com"
print ('Hello World, this is %s with HNGi7 ID- %s using %s for stage 2 task. Email %s' %(fullname, HNGi7ID, language, email))
