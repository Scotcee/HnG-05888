<?php

//variable declaration and initialization
$fullname = "Nwodo Chidubem Emmanuel";
$id = "HNG-06677";
$email = "nwodochidubem1@gmail.com";
$language = "PHP";

//placing the variables into the output
$info = "Hello World, this is " . $fullname . " with HNGi7 ID " . $id . " using " . $language . " for stage 2 task. " . $email;

echo $info;
