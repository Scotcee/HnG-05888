var myFullName = "OJO BABAJIDE OLAYINKA";
var myHngId = "HNG-04603";
var myLangOfChoice = "JAVASCRIPT";
var myEmailAdd = "ojobabajide629@gmail.com";

console.log("Hello World, this is ${myFullName} with HNG-ID ${myHngId} using ${myLangOfChoice} for stage 2 task. ${myEmailAdd}");
