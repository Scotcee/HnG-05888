const myIntroScript = (fullName, hng_ID, lang) => {
	console.log(
		`Hello World, this is ${fullName} with HNGI7 ID ${hng_ID} using ${lang} for Stage 2 task`
	);
};

myIntroScript("Mustapha Sani", "HNG00134", "nodejs");
