<?php
$name = "Arthur Obel";
$id = "HNG-00226";
$language= "php";

echo "Hello world, this is $name with HNGi7 ID $id using $language for stage 2 task. Obelarthur@gmail.com";
?>
