name = "Akintayo Ifeoluwa Janet"
ID="HNG-00295"
language="python"
email="akintayoife94@gmail.com"
print ("Hello World,this is", name, "with HNGi7 ID", ID, "using", language, "for stage 2 task.", email, flush=True)