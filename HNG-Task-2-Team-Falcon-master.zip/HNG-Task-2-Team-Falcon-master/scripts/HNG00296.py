def HNG_task():
    print('Hello World, this is Vikas Rathore with HNGi7 ID HNG-00296 using Python for stage 2 task. vikasrathour162@gmail.com')
HNG_task()
