<?php
$name = "Alajiki Temilola";
$id = "HNG-00444";
$language = "PHP";
$email = "alajikitemilola@gmail.com";

echo "Hello World, this is " .$name.  " with HNGi7 ID ".$id. " using " .$language. " for stage 2 task. " .$email ;

?>
