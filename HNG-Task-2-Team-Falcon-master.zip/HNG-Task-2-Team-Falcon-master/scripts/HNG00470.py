print('Hello World, this is Osarumwense Blessing Eseosa with HNGi7 ID HNG-00470 using Python for stage 2 task. blessingosarumwense2@gmail.com')
