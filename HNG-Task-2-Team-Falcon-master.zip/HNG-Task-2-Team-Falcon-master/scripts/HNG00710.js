let Name = 'Akinsola Moses';
let Id = 'HNG-00710';
let Language = 'javascript';
let Email = 'olulare6@gmail.com';

function returnString()
{
   const message = 'Hello World, this is '+ Name + ' with HNGi7 ID '+ Id+' using '+Language+' for stage 2 task. '+Email;
    return message;
}

console.log(returnString());
