

/** Variable Declaration */

var name = "Simeon Fadahunsi";
var id = "HNG-00838";
var email = "adedayosimeon@gmail.com";
var language = "JavaScript";


/** Console Output */

console.log("Hello World, this is " + name + " with HNGi7 ID "+ id + " using " + language + " for stage 2 task. " +email);
