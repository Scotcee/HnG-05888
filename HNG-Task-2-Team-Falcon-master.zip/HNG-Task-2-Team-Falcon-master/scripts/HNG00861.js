const myHNGAccountDetails = () => {
    const fullName = `Alao Abiodun AbdulRahman`;
    const hngID = `00861`;
    const programmingLanguage = `JavaScript`;
    const myhngAccountDetails = `Hello World, this is ${fullName} with HNGi7 ID ${hngID} using ${programmingLanguage} for stage 2 task`;
    return myhngAccountDetails;
}

myHNGAccountDetails();