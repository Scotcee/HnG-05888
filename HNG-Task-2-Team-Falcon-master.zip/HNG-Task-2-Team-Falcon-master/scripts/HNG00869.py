Hng_Details = input(
    "Hello world, this is Adeyemi Oluwatobi with HNGi7 ID of HNG-00869 using Python language for stage 2 task. tobinuel155@gmail.com ")

print(Hng_Details)
