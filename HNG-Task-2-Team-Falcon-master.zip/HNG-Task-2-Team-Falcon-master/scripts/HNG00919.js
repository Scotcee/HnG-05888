function caller (){
    let name = "Mmonim Ukpanah"
    let id = "HNG-00919"
    let language= "Javascript" 
    console.log ('Hello world, this is' + ' ' + name +  ' '+ 'with HNGi7 id' +' ' + id + ' '+ 'using' + ' ' + language + ' ' + 'for stage 2 task. mukpanah22@gmail.com')
}


caller()