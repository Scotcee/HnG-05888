fullname = 'Kazeem Hakeem'
ID = '01404'
language = 'python'
email = 'hakymulla@gmail.com'

print(f"Hello World, this is {fullname} with HNGi7 ID {ID} using {language} for stage 2 task. {email}")
