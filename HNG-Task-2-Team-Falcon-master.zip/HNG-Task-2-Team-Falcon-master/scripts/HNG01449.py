name = "Seffu Kioi"
hngid = "HNG-01449"
email = "seffukioi@gmail.com"
lang = "Python"

print("Hello World, this is {} of email {} with HNGi7 ID {} using {} for stage 2 task".format(name,email,hngid,lang))
