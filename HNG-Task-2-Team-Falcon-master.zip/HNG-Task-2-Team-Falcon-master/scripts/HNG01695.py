
print ("Hello World, this is Victoria Akilapa with HNGi7 ID HNG-01695 using Python for stage 2 task.drvictoriaakilapa@gmail.com")

