task_2 = 'Hello World, this is Chiazam OCHIEGBU with HNGi7 ID HNG-02596 and email chizzydmec@gmail.com using Python for stage 2 task.'
print(task_2)
