console.log("Hello World, this is Achonwa Chiemezuo with HNGi7 HNG-02941 using JavaScript for stage 2 task alvanmexix@gmail.com");
