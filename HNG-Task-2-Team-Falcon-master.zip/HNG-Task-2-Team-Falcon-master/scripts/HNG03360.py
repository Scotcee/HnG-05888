mystring='Hello World, this is Oyebade Victor Olamilekan with HNGi7 ID HNG-03360 using python for stage 2 task'
myemail='oyebadev@gmail.com'
print(mystring)
print(myemail)
