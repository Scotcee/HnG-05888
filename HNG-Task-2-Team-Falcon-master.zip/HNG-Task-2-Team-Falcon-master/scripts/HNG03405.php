<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HNG-03405 FirstTask</title>
</head>
<body>
<?php 
echo "<Hello World, this is Olatunde Ibitoye with HNGi7 ID HNG-03405 <br> using PHP for stage 2 task. <br> horlartundhey@gmail.com";
?>
    
</body>
</html>
