function hng03923(){
    let fullName = 'chidera johnson';
    let id = 'HNG-03923';
    let languageUsed = 'Javascript';
    let emailAddress = 'derajohnson64@gmail.com';
    let completeInitials = `Hello World, this is ${fullName} with HNGi7 ID ${id} using ${languageUsed} for stage 2 task. ${emailAddress}`

     return completeInitials
}

console.log(hng03923())
