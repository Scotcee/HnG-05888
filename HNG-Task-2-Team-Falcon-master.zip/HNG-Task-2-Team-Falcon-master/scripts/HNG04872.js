var message = "Hello World";
var info = {
"name": "Arege Amos Dizza",
"HNGi7ID": "04872",
"language": "JavaScript",
"emailAddress": "Aregeamos@gmail.com"
};
console.log(message+= " this is " + info.name + " with HNGi7 ID " + info.HNGi7ID + " using " + info.language  + " stage2 task. " + info.emailAddress);