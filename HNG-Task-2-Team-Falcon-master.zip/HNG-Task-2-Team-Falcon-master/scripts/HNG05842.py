print("Hello Wold, this is Lawrence Ayobami with HNG05842 using python for stage 2. ayobamilawrence@gmail.com ")
