<?php

//STAGE 2 TASK

$internName = "Etukudo Emmanuel";
$internID = "HNG-05965";
$internLanguage = "PHP";
$internEmail = "etukzbong@gmail.com";

$statement = "Hello World, this is ".$internName." with HNGi7 ID ".$internID." using ".$internLanguage." for stage 2 task. ".$internEmail;

echo $statement;


?>
