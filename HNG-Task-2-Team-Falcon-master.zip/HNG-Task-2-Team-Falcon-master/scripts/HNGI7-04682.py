def hngtask2():
    h1 = ('hello world,')
    print (h1)
    Full_Name = ('this is koyi olamilekan')
    print (Full_Name) 
    hng_id = ('with hngi7id- 04682')
    print (hng_id)
    language = ('using python for stage 2 task')
    print (language)
    Address = ('lekan.koyi@gmail.com')
    print (Address)
hngtask2()

