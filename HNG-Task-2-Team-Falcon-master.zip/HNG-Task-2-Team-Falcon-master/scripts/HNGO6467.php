<?php
$hng_id ="HNG-06467" ;
$name ="taiwo" ;
$language = "php";
echo "Hello World, this is [$name] with HNGi7 ID [$hng_id] using [$language]  for stage 2 task";
?>
