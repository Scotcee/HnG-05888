console.log('Hello World, this is Kenechukwu Ugwu with HNGi7 ID HNG-03516 using javascript for stage 2 task')
