let fullName = 'Jessica Ojadi';
let HNG_ID = 'HNG_01561';
let email = 'jessicaojadi@gmail.com';
let languageType = "JavaScript";
console.log("Hello World, this is " + fullName + " with HNGi7 ID " + HNG_ID + " using " + languageType + " for stage 2 task" + " " + email);