greetings = 'Hello World, this is '
intern_name = 'Ibibo Seleye Fubara'
connector = ' with ID '
intern_id = ' HNG-02197'
connector2 = ' Using '
intern_language = ' python for task 2'
email = ' ibibofubara@gmail.com'


profile = greetings + '' + intern_name + '' + connector + '' + intern_id + '' + connector2 + '' + intern_language + '' + email

print(profile)
