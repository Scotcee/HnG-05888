var fullname = 'olawale micheal juwon';
var ID = 'HNG-02415';
var email = 'olawalejuwon@gmail.com';
var language = "JAVASCRIPT";
console.log("Hello World, this is " + fullname + " with HNGi7 ID " + ID + " using " + language + " for stage 2 task." + " " + email);
