full_name = "Fatima - Bint Ibrahim"
ID = "HNG-03156"
language = "Python"
email = "fatimatib44@gmail.com"

print("Hello World, this is " +full_name+" with HNGi7 ID "+ID+" using "+language+" for stage 2 task. "+email)
