let fullName = 'Anita-Angela Ojadi';
let HNG_ID = 'HNG_03810';
let Email = 'ojadianita@gmail.com';
let langType = "JavaScript";
console.log("Hello World, this is " + fullName + " with HNGi7 ID " + HNG_ID + " using " + langType + " for stage 2 task" + " " + Email);