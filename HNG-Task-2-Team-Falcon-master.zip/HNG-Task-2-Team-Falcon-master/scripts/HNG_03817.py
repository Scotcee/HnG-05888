full_name= 'Obaro Rachael'
HNGi7_ID='HNG-03817'
language= ' python '
email='obaro.rachaels@gmail.com'


print(f'Hello World, this is {full_name} with HNGi7 ID {HNGi7_ID} using {language} for stage 2 task. {email}',flush=True)
