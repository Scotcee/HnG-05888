def Task_Two(Name, HNG_ID, Lang):
    return print("Hello World, this is {} with HNGi7 ID {} using {} for stage 2 task. josephedoh77@gmail.com".format(Name, HNG_ID, Lang))

Name = "Edoh Joseph Onome"
HNG_ID = "HNG-04518"
Lang = "Python"

Task_Two(Name, HNG_ID, Lang)
