
    const greetings = "Hello World,"
    const myName = "this is Emmanuel Chijioke with HNGi7 ID HNG-02581 using JavaScript for stage 2 task"
    const email = "manuelckay@gmail.com"
    console.log(greetings + " " + myName)
    
