//const names
const firstName = 'olawale';
const lastName = 'olanrewaju';
const id = 'HNG-06086';
const email = 'olawaleolanrewaju3@gmail.com';
let language = 'JavaScript';

console.log(`Hello World, this is ${firstName} ${lastName} with HNGi7 ID ${id} using ${language} for stage 2 task. ${email}`);
