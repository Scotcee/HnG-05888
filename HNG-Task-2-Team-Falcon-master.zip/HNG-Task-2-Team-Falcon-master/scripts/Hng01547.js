function Hng_task2() {
  const name = "Shubham Thakre";
  const id = "HNG-01547";
  const language = "JavaScript";
  const email = "thakres955@gmail.com";
  console.log(
    "Hello World, this is" +
      " " +
      name +
      " " +
      "with HNGi7 ID" +
      " " +
      id +
      " " +
      "using" +
      " " +
      language +
      " " +
      "for stage 2 task." +
      " " +
      email
  );
}
Hng_task2();
