function Hng_task2() {
  const name = "Tejumola Bolu";
  const id = "HNG-2542";
  const language = "JavaScript";
  const Email = "tejumolabolu@gmail.com";
  console.log(
    "Hello World, this is" +
      " " +
      name +
      " " +
      "with HNGi7_ID:" +
      id +
      " " +
      "using" +
      " " +
      language +
      " " +
      "for stage 2 task." +
      " " +
      "email:" +
      Email
  );
}
Hng_task2();
