print("Hello World, this is Alahira Jeffrey Calvin with HNGi7 ID U014HMD5VL5 using python for stage 2 task"
