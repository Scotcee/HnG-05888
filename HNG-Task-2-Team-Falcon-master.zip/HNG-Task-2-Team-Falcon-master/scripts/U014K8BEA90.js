(
    function greeting() {

        let sFullName = "Manuel Rodriguez Romero";
        let sHngi7Id  = "U014K8BEA90";
        let sLanguage = "JavaScript";
        let sEmail    = "man.rdguez@gmail.com";

        let sGreeting = "Hello World, this is "
                      + sFullName
                      + " with HNGi7 ID "
                      + sHngi7Id
                      + " and email "
                      + sEmail
                      + " using "
                      + sLanguage
                      + " for stage 2 task";

        console.log( sGreeting );
    }
) ();
