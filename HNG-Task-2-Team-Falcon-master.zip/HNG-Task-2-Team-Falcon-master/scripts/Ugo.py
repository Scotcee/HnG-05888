full_name = "Ugochukwu Umeh"
HNG_ID = "HNG-03398"
email = "uumeh428@gmail.com"
lang = "Python"

output = f"Hello World, this is {full_name} with HNGi7 ID {HNG_ID} using {lang} for stage 2 task. {email}"

print(output, flush = True)



