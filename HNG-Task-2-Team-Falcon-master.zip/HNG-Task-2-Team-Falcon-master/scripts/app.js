let fullname = 'Obidike lawrence',
      hngid  =  'INTERNSHIP ID: HNG-01239',
      email  ='obidikelawrence11@gmail.com',
    language = 'Javascript';

    function Task2 (){
       return `hello world, this is ${fullname}, with ${hngid} using ${language} for stage 2 task. ${email}`
    };

    console.log(Task2());