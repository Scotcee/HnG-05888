/*
*
* @author Adeola Adediran
* function intro() 
*
*/

function introduction() {
  let name, id, email, language;
  name = "Adeola Adediran"
  id = "HNG-00625";
  email = "adexdsamson@gmail.com";
  language = "Javascript";
  let output = `Hello World, this is ${name} with HNGi7 ID ${id} using ${language} for stage 2 task. ${email}`;
  console.log(output)
};

introduction();
