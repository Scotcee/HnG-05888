>>> print ('Hello World, this is Chizurum Nwachukwu with HNGi7 ID HNG-00972 using Pyhton for stage 2 task')
