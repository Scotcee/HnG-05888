print("Hello World, this is David Evbodaghe with HNGi7 ID HNG-01518 using Python for stage 2 task. devbodaghe98@gmail.com")
