def name (self):

    return name
name(self=name)

