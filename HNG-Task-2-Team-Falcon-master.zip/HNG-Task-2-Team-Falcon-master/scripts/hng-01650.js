
function task2() {
  
  const name = "Omotosho David";
  const id = "HNG-01650";
  const language = "JavaScript";
  const Email = "talk2adeoluwa2310@gmail.com";
  console.log("Hello World, this is" + " " + name + " " + "with HNGi7_ID:" +
      id + " " + "using" + " " + language + " " + "for stage 2 task." + " " + "email:" + Email
  );
}


task2();
