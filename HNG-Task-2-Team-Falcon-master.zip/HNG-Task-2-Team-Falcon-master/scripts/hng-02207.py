Fullname = 'Ayomide Emmanuel'
ID = "HNG-02207"
Language = "Python"
Email = "ayomide.adegboro2001@gmail.com"
print ('Hello World, this is {Fullname} with HNGi7 ID {ID} using {Language} for stage 2 task. {Email}'.format(**locals()))
