<?php

$fullName = "Ifeanyi Okoroafor";
$id = "HNG-02665";
$language = "php";
$stage = 2;

echo ("Hello World, this is " .$fullName. " with HNGi7 ID " .$id. " using " .$language . " for stage " .$stage . " task");

?>
