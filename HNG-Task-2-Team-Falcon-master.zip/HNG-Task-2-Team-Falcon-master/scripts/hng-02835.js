const scriptTask = () => {

    let name = 'Ntwari Moise';
    let id = 'HNG-02835';
    let language = 'JavaScript';
    let email  = 'mozayntwali@gmail.com';

    console.log(`Hello World, this is ${name} with HNGi7 ID ${id} using ${language} for stage 2 task. ${email}`);
};

scriptTask();