var bio = {
        name: 'David Ogunniran',
        hngId: '03639',
        lang: 'Javascript',
        email: 'ayodeleogunniran@gmail.com'
    }

function result() {
    console.log ( 'Hello World, this is ' + bio.name + ' with HNGi7 ID ' + bio.hngId + ' using ' + bio.lang + ' for stage 2 task ' + bio.email)
    return true
}

result()