print("Hello World, this is Samuel Adekoya with HNG7 ID HNG-04399 using python for stage 2 task")
