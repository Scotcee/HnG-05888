<?php


echo "Hello World, this is Andikan Affiah, with HNGi7 ID HNG-05249 using PHP for stage 2 task";

?>