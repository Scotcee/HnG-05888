const stage2Task = (fullName, hngId, language) => {
	return console.log(
		`Hello World, this is ${fullName} with HNGi7 ID ${hngId} using ${language} for stage 2 task. hawau.olamide.th@gmail.com`
	);
};
stage2Task("Toyin Hawau Olamide", "HNG-05458", "JavaScript");
