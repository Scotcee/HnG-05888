//Task 2 Team Falcon
//Hello World and my details in JavaScript

var myString = "Hello World, this is Oyin Oyegoke with HNGi7 ID HNG-06463 using Javascript for stage 2 task. oyinlolu@gmail.com"

console.log(myString);

//I have created a string variable and printed it's contents. 