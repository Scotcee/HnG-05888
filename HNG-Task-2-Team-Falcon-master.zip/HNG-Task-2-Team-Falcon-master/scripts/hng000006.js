function message() { 
 var fullName = "Azubuike Nnamdi Clement";
var hngId = "HNG-03331";
var email = "blessedmarcel1@gmail.com";
var language = "JavaScript";

 return("Hello world I am " + fullName + " by name with " + hngId + " and slack email " + email + " using " + language + " for stage 2 task ") ;
}

console.log(message ())
