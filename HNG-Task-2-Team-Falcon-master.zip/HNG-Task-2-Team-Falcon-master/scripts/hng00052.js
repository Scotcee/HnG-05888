console.log('Hello World, this is Adedayo Adeyanju with HNGi7 ID HNG-00052 using JavaScript for stage 2 task. adedayoadeyanju.aa@gmail.com');

