console.log('Hello World, this is Thomas Rita with HNGi7 ID HNG-00282 using Javascript for stage 2 task. auxano42@gmail.com')
