const printMessage = () => {
  const name = 'Zimuzo Obiechina';
  const id = 'HNG-00327';
  const lang = 'JavaScript';
  const email = 'zimobie@gmail.com';

  console.log(
    `Hello World, this is ${name} with HNGi7 ID ${id} using ${lang} for stage 2 task. ${email}`
  );
};

printMessage();