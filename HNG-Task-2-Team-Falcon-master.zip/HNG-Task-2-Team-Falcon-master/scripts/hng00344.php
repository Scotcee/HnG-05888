<?php
$name = 'Milind krishna ';
$hngi7_id = '00344';
$language = 'PHP' ;
$c = 'Hello World! this is'. $name.'with' $hngi7_id.'using' $language. 'for stage 2 task' ;
echo " $c ";
?>
