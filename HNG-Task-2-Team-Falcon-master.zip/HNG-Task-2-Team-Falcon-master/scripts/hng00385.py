name = 'Oluwadamilola Sonaike'
id = 'HNG-00385'
pro_lang = 'Python'
email = 'damiso15@yahoo.com'

print(f'Hello World, this is {name} with HNGi7 ID {id} using {pro_lang} for stage 2 task. {email}')
