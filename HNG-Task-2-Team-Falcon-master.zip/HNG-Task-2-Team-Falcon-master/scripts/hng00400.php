<?php

// HNGi7 task 2: Just details about my profile

$fullname = "Jaiyeola Matin Oluwaseun";

$hngID = "HNG-00400";

$lang = "PHP";

$email= "martinjaiyeola40@gmail.com";

$result = "Hello World, this is " . $fullname .

          " with HNGi7 ID " . $hngID . 

          " using " . $lang . " for stage 2 task. " . $email;

echo $result;

?>






















