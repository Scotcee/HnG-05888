let details = {
    fullName: "Fredrick kelly",  
    language: "JavaScript",
    hngID: "HNG-00468",
    email: "kellyonline2016@gmail.com"
};
  
const message = `Hello World, this is ${details.fullName} with HNGi7 ID ${details.hngID} using ${details.language} for stage 2 task. ${details.email}`;

console.log(message);
  
