let myName = 'Ajanaku Ridwan'
let id = 'HNG-00496'
let lang = 'Javascript'
let email = 'lakes.ajanaku@gmail.com'

output = 'Hello World, this is '+ myName + ' with HNGi7 ID '+ id +' using '+ lang +' for stage 2 task. '+email

console.log(output)