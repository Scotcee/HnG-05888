const HNG = {
  name: "Tolulope Popoola",
  id: "HNG-00515",
  email: "tolulopeontop@gmail.com",
  lang: "JavaScript",
};
console.log(
  `Hello World, this is ${HNG.name} with HNGi7 ID ${HNG.id} using ${HNG.lang} for stage 2 task. ${HNG.email}`
);
