const hngTask2 = (fullName, id, language, email) => {
    console.log(
        `Hello World, this is ${fullName} with HNGi7 ID ${id} using ${language} for stage 2 task ${email}`
        );
};

hngTask2(
    'Bamidele Ashiru', 
    'HNG-00518', 
    'Javascript', 
    'ashirubamidele17@gmail.com'
);
