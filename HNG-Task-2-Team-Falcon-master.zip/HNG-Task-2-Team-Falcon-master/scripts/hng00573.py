string_name = 'Martins Olatunji'
string_HNGi7ID = 'HNG-00573'
string_language = 'python'
string_email = 'martinsolatunji2@gmail.com'

print ("Hello World, this is " +string_name+ " with HNGi7 ID " +string_HNGi7ID+ " using " +string_language+ " for stage 2 task. " +string_email)
