print("Hello World! \nThis is Emmanuel Igwe with HNG-00798 using Python for stage 2 task. \nhaymakermow@gmail.com")
