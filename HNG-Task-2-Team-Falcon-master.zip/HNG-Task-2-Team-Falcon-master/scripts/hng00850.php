<?php

$name = 'Gabriel Isaac';
$id = 'HNG-00850';
$language = 'php';
$email = 'iamkemical1@gmail.com';

echo "Hello World, this is {$name} with HNGi7 ID {$id} using {$language} for stage 2 task. {$email}";

?>
