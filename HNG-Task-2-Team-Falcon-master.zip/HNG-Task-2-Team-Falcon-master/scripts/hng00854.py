full_name = 'Odafe Akpoborie'
hng_id = 'HNG-00854'
lang = 'Python'
email = 'ohdahphae@gmail.com'

def func(full_name, id, lang, email):
    return f'Hello World, this is {full_name} with HNGi7 ID {hng_id} using {lang} for stage 2 task. {email}'

print(func(full_name, hng_id, lang, email), flush=True)
