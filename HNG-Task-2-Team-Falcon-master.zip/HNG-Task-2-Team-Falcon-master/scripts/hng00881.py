print("Hello World,this is Agboso Chinedu Kelvin with HNGI7 1D HNG-00881 using python for stage 2 task")
