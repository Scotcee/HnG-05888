

const hng00890 = (name, id, language, email) => {
  
    const task_two = `Hello World, this is ${name} with HNGi7 ID HNG-${id} using ${language} for stage 2 task ${email}`;

    console.log(task_two);
}

hng00890('Babatunde Abdulhameed', '00890', 'Javascript', 'humiditii45@gmail.com')