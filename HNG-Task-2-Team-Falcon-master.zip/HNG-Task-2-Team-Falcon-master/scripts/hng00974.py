# hng00974.py
print('Hello World, this is Ruth Enechojo Akagwu with HNGi7 ID 00974, email udohruthie@gmail.com, using python for stage 2 task')
