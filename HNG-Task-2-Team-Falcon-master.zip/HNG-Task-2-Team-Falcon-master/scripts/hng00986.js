//First step is to store all your words in Variables
//Echo(Print) them at the end using the console.log() Function. Simple:

var text1 = "Hello World, this is ";
var fullName = "Christian Asarhasa ";
var text2 = "with HNGi7 ID, ";
var id = "HNG-000986 ";
var text3 = "using ";
var language = "Javascript ";
var text4 = "for Stage 2 Task, ";
var email = "jamiesplendour@gmail.com.";

console.log(text1 + fullName + text2 + id + text3 + language + text4 + email);
