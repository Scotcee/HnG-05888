<?php
echo "Hello World,
this is Adim Ekene
with HNGi7 ID HNG-01086
using PHP for stage 2 task.
ekeneadim@gmail.com";
?>
