def taskCode():
    my_name = "Oluwatosin Taiwo"
    hng_id = "HNG-01224"
    language = "Python"
    email = "ttvicktor1@gmail.com"
    print("Hello World, this is " + my_name + " with HNGi7 ID " + hng_id "using " + language "for stage2 task");

taskCode()
