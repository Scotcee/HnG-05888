print("Hello world, this is Akere Mukhtar with HNGi7 ID HNG-01259 using Python for stage 2 Task")
