print('Hello World, this is Victor Adesanya with HNGi7 ID HNG-01330 using Python for the stage 2 task')
