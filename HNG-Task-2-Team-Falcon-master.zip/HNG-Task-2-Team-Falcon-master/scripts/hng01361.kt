fname = "Olatoye Daniel Timilehin"
id = "HNG-01361"
language = "python"
email = "olatoyedan@gmail.com"
final_result = "Hello world, this is " + fname + " with HNGi7 ID " + id + " using " + language + " for stage 2 Task " + email
print(final_result)