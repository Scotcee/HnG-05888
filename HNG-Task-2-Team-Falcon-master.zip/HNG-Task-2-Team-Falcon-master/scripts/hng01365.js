let fullName = "Gbenga Owoeye";
let hngId = "HNG-01365";
let email = "gbengaowoeye43@gmail.com";
let lang = "JavaScript";

console.log(
  `Hello World, this is ${fullName} with HNGi7 ID ${hngId} using ${lang} for stage 2 task. ${email}`);

