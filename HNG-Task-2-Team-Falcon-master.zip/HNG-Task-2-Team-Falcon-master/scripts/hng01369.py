# hng stage1 task

# Declaring variables
fullName = "Nwankwo Osoraa"
hngId = "HNG-01369"
language = "Python"
email = "sochi98.sn@gmail.com"

# Printing to screen
print("Hello World, this is " + fullName + " with HNGi7 ID " + hngId + " using " + language + " for stage 2 task. " + email)
