<?php
function pullRequest() {
return "Hello World, this is Polycarp with HNGi7 ID HNG-01415 using PHP for stage 2 task. polycarpatalor@gmail.com";
}
echo pullRequest();
?>
