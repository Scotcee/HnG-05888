const output = "Hello World, this is Essien, David Itam with HNGi7 ID 01421 using Javascript for stage 2 task. davidessienshare@gmail.com"
console.log(output);