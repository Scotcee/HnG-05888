process.stdout.write("Hello World, this is Usman Suleiman with HNGi7 ID HNG-01428 using JavaScript for stage 2 task. usmansbk@gmail.com ");
