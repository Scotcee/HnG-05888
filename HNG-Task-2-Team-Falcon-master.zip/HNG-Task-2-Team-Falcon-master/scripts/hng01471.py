my_name = "Athumani Mwinami"
internship_id = "HNG-01471"
language = 'Python'

task1 = f"Hello World, this is {my_name} with HNGi7 ID {internship_id} using {language} for stage 2 task"

print(task1)