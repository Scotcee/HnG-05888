"Hello World, this is [fullname] with HNGi7 ID [ID] using [language] for stage 2 task".[email].
const fullName = 'Helen Chinedu';
const id = '01511';
const language = 'Javascript';
const email = 'helenchinedu26@gmail.com';
console.log(`Hello World, this is ${fullName} with HNGi7 ID ${id} using ${language} for stage 2 task. ${email}`)
