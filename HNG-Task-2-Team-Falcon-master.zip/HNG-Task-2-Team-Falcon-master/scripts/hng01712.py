full_name = "Oluwaseun Olu-Young"
hng_id = "HNG 01712"
language_name = "Python"


print("Hello world, this is (full_name) with HNGi7 ID (hng_id) using (language_name) for stage 2 task", flush=True)
