const hngId = "01780",
  progLang = "JavaScript",
  fullName = "Olajide Hammed Abayomi",
  email = "olajide.a.hammed@gmail.com";

console.log(
  `Hello World, this is ${fullName} with HNGi7 ID ${hngId} using ${progLang} for stage 2 task. ${email}`
);
