<?php

function stage2Task(){
	return "Hello World, this is Ejiroghene Obiuwevbi with HNGi7 ID HNG-01797 using PHP for stage 2 task. ejiroghene15@gmail.com";	
}

echo stage2Task();
?>