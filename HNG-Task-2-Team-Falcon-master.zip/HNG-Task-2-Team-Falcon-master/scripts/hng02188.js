function calling() {
  let hngId = "HNG-02188";
  let name = "Oluwaferanmi Adedokun";
  let stack = "Javascript";
  let email = "adedokunoluwaferanmi@gmail.com";

  console.log(
    `Hello World, this is ${name} with HNGi7 ID ${hngId} using ${stack} for stage 2 task`
  );
}
calling();
