def my_hngi7_details():
    fullname = 'onuh Chukwuma'
    id = "HNG-02260"
    language = "Python"
    email = "onuhchukwuma12@gmail.com"
    print('Hello World, this is {}  with HNGi7 ID {} using {} for stage 2 task. {}'.format(fullname,id,language,email),flush=True)
    
my_hngi7_details()


