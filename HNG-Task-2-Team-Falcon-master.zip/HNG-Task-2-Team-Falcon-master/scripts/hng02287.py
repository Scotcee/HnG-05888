name = "Kolapo Opeoluwa Olamidun"
language = "Python"
email_address = "kolapoolamidun@gmail.com"
greeting = "Hello World, this {} with HNGi7 ID HNG-02287 using {} for stage 2 task. {}"
print(greeting.format(name, language, email_address))

