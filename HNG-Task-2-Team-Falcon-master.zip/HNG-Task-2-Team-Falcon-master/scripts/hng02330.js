var name = "Emi Udisi"
var language = "javascript"
var id = "HNG-02330"
var email = "michaelemiudisi@gmail.com"
console.log("Hello World, this is " + name + " with HNGi7 ID " + id + " using " + language + " for stage 2 task. " + email)
