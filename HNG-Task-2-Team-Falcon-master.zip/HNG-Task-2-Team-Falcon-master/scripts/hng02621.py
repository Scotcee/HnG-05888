Name = 'Chikezie Ikeche'
Language = 'Python'
id = "02621"
email = "ikechex@gmail.com"

print("Hello World, this is", (Name), "with HNGi7 ID", (id), "and email", (email), "using", (Language), "for stage 2 test", flush=True)
