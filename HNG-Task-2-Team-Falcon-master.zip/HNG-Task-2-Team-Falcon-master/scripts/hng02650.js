var nom = "Mariam Kalala";
var postnom = "Cisse";
var id = "HNG-02650";
var lang = "JavaScript";
var email ="2017mkjawara@gmail.com";

console.log("Hello World, this is "+nom+" "+postnom+" "+"with HNGi7 ID "+id+" "+"using "+lang+" "+"for stage 2 task."+" "+email);
