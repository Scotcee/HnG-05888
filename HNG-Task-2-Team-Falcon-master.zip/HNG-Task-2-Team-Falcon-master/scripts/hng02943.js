// my information
const userData = {
  fullName: 'Lazarus Nwankwo',
  id: 'HNG-02943',
  language: 'JavaScript',
  email: 'lazicah@gmail.com'
}


console.log(`Hello World, this is ${userData.fullName} with HNGi7 ID ${userData.id} using ${userData.language} for stage 2 task. ${userData.email}`)
