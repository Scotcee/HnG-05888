
console.log("Hello World, this is Lucas Gomez with HNGi7 ID HNG-02962 using JavaScript for stage 2 task. gomez.d.lucas@gmail.com")
