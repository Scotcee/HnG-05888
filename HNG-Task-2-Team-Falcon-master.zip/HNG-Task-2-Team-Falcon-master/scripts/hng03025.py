def hng_task2():
    name = "Nelson Okoye"
    identification = "HNG-03025"
    language = "Python"
    email = "nlsnokoye@gmail.com"

    print(f"Hello World, this is {name} with HNGi7 ID {identification} using {language} for stage 2 task. {email}")


hng_task2()
