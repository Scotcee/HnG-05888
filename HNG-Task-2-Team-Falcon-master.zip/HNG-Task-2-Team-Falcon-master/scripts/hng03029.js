let name = 'Obu Chigozie'
let id = 'HNG-03029'
let lang = 'JavaScript'
let email = 'lawrenceobu@gmail.com'

console.log(`Hello World, this is ${name} with HNGi7 ID ${id} using ${lang} for stage 2 task. ${email}`)
