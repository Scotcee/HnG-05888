
mystring = 'Hello World, this is Kelechi Precious Nwachukwu with HNGi7 ID:03042 using Spyder(Python 3.7) for stage 2 task.'


print('mystring',flush=True)
