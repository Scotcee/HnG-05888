console.log("Hello World, this is Kiran Mate with HNGi7 ID [HNG-03237] using [javascript] for stage 2 task");
