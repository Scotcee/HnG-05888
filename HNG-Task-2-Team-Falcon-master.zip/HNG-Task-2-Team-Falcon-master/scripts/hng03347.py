import sys



print("Hello World, this is Chiagozie Robert with HNGi7 ID HNG-00347 using Python for stage 2 task. robertchiagozie@gmail.com")
sys.stdout.flush()
