<?php
//a simple print out statement

$name = "Sylvester Akwaowo";
$id = "HNG-03495";
$lang = "PHP";
$email="ultrasoft101@gmail.com";

echo
"Hello World, this is $name with HNGi7 ID $id using $lang for stage 2 task. $email";
?>
