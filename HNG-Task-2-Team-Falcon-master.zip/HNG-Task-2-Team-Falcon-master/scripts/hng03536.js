const fullName = "Divine Philip";
const hngID = "HNG-03536";
const language = "JavaScript";
const email = "dpkreativ@gmail.com";

returnStatement = () => {
  return `Hello World, this is ${fullName} with HNGi7 ID ${hngID} using ${language} for stage 2 task. ${email}`;
}

console.log(returnStatement());
