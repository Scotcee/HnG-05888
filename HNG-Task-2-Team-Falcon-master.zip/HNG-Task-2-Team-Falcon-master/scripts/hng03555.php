<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HNG-Task-2-Team-Falcon-JeremiahIro-HNG-03555</title>
</head>
<body>
    <?php 
        echo '<p>Hello World</p>'; 
        echo '<h4>This is JEREMIAH FAVOUR IROMAKA with HNGi7 ID 03555 using PHP for stage 2 task</h4>'; 
        ?> 
</body>
</html>