<?php
$id = "HNG-03600";
$name = "Kofi Mokome";
$language = "PHP";
$email = "kofimokome10@gmail.com";

echo sprintf("Hello World, this is %s with HNGi7 ID %s using %s for stage 2 task. %s",$name,$id,$language,$email);
