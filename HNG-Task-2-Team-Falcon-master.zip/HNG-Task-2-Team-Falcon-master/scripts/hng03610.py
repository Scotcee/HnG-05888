full_name = "Victor Rwuaan"
id = "HNG-03610"
language = "python"
email = "abarau47@yahoo.com"
print("Hello World, this is",full_name,"with HNGi7 ID",id,"using", language,"for stage 2 task.",email, flush=True)