full_name= "Ewerechukwu Favour Asaka"
hng_id="HNG-03621"
language="Python"
email="ewereasaka@gmail.com"
print("Hello World, this is "+ full_name+ " with HNGi7 ID "+hng_id+ " using "+language+ " for stage 2 task. "+ email )
