var fullName = "Comfort Nyatsine";
var id = "HNG-03622";
var email = "comfynyatsine@gmail.com";
var language = "JavaScript";

function myTask(){
      return console.log(`Hello World, this is ${fullName} with HNGi7 ID ${id} using ${language} for stage 2 task. ${email}`);
};
myTask();

