<?php
 $name = "Emediong Ukpong";
 $language = "PHP";
 $hngid = "HNG-03654";
 $mail = "ukpongemediong.eu@gmail.com";
 echo "Hello World, this is $name with HNGi7 ID $hngid using $language for stage 2 task. $mail";
?>
