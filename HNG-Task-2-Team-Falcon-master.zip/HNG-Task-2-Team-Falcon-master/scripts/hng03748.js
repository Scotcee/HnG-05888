function intro(name, id, lang) {
  return `Hello World, this is ${name} with HNGi7 ID ${id} using ${lang} for stage 2 task.`;
}
console.log(intro("Lukman Isiaka", "HNG-03748", "JavaScript"));
