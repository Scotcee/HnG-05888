# full name
fullName = 'Eyawo Okiemute Scott'
# id name
ID = 'HNG-04199'
# language
language = 'python'
# email address
emailAddress = 'Scotteyawo@gmail.com'

print(f"Hello World, this is {fullName} with HNGi7 ID {ID} using {language} for stage 2 task. {emailAddress}")
