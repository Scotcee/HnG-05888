 const FullName = 'Oludayo Solarin';
const HNGID = 'HNG-04262';
const Language = 'JavaScript';
const Email = 'solarinoludayo@gmail.com';

console.log(`Hello World, this is ${FullName} with HNGi7 ID ${HNGID} using ${Language} for stage 2 task. ${Email}`)
