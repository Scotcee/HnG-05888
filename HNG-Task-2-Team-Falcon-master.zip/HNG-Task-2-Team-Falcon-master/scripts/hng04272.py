def details():
    fullname = "Precious Ngwube"
    hngid = str('HNG-04272')
    language = "Python"
    print(f'Hello World, this is {fullname} with HNGi7 ID {hngid} using {language} for stage 2 task. pngwube@gmail.com', flush=True)

details()
