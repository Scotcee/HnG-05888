<?php
$fullname = "Okorie Joseph Ifeanyi";
$id = "HNG-04397";
$language = "php";


echo "Hello World, this is " . $fullname. " with HNGi7 ID " .$id. " using " .$language. " for stage 2 task. josephokorie32@gmail.com";

?>
