name = "Juma Aisha"
HNG_id = 04499
language = "python"
email = "alishadesua1@gmail.com"
print("Hello World, this is " + name + "with HNGi7 ID :" + HNG_id + "and email address: " + email + " using " + language + " for stage 2" )



