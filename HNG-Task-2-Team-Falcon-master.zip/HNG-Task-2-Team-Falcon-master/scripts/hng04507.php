
<?php 
$fullname = 'Odeajo Israel';
$id = 'HNG-04507';
$lang = 'php';
$email = 'iodeajo@gmail.com';

echo "Hello World, this is " . $fullname . " with HNGi7 ID  ".  $id. "with email ". $email ." using " . $lang . " for stage2 task";
?>