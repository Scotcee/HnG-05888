<!DOCTYPE html>
<html>
<head>
	<title>Hello World</title>
</head>
<body>
<?php 
echo "Hello World this is Abiola Olokodana with HNGi7 ID 04521 using PHP for stage 2 email banjiolokodana@outlook.com "; 
?>
</body>
</html>
