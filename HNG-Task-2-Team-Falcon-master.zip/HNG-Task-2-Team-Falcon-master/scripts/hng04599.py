def announce(name, id, language, email):
    message = f"Hello World, this is {name} with HNGi7 ID {id} using {language} for stage 2 task. {email}"
    print(message, flush=True)

announce('Adedamola Alege', 'HNG-04599', 'python', 'alegedamola@gmail.com')
