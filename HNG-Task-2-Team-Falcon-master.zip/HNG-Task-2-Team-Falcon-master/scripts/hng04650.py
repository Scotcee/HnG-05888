fullName = "Henry Hogan"
idNumber = "HNG-04650"
lang = "python"
emailAddress = "henry.hogan2012@gmail.com"

print("Hello World, this is %s with HNGi7 ID %s using %s for stage 2 task. %s" %(fullName, idNumber, lang, emailAddress), flush=True)
