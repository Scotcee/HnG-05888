const Hng_task2 = () => {
   const name = "Daniel Chukwuma";
   const id = "HNG-04725";
   const language = "JavaScript(NodeJs)";
   const email = "iamdanielchukwuma@gmail.com";
   console.log(
      `Hello World, this is ${name} with HNGi7 ID ${id} using ${language} for stage 2 task. ${email}`
   );
};

Hng_task2();
