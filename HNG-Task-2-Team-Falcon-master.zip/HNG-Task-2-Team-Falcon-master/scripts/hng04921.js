const fullName = "Chizaram Nwazuo";
const id = "HNG-04921";
const language = "JavaScript";
const email = "chizonwazuo@yahoo.com";

console.log(`Hello Word, this is ${fullName} with HNGi7 ID ${id} using ${language} for stage 2 task. ${email}`);
