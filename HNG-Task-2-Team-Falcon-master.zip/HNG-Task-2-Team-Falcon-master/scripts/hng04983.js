const fullName = 'Chukwuma Ajunwa';
const hngId = 'HNG-04983';
const lang = 'Javascript';
const email = 'chukwuma.ajunwa@gmail.com';

console.log(`Hello World, this is ${fullName} with HNGi7 ID ${hngId} using ${lang} for stage 2 task. ${email}`);
