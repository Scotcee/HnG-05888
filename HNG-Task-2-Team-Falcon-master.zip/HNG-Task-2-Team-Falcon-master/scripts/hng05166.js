function hng05166(){
  
let name = "Ayomide Oso Susan";
let ID = "HNG-05166";
let language = "JavaScript";
let email = "ayomideosho13@gmail.com";
  
console.log("Hello World, this is " + name + " with HNGi7 ID " + ID +  " using " + language + " for stage 2 task. " + email);
};

hng05166();
