console.log("Hello World, this is Oku Emmanuella Adaugo with HNGi7 ID 05293 using javascript for stage 2 task.  adaugooku01@gmail.com.");

