let firstName = "Abdurrahman";
let lastName = "Abolaji";
let fullName = firstName + " " + lastName;
let id = "HNG-05355";
let email = "abolajiabdurrahman@gmail.com";
let language = javascript;

console.log(`Hello World, this is ${fullName} with HNGi7 ID ${id} using ${language} for stage 2 task. ${email}`);
