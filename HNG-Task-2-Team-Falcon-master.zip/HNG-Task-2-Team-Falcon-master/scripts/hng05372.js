var fullName, id, language, email;
fullName = 'Anyaebosi Uchenna';
id = 'HNG-05372';
language = 'Javascript';
email = 'ucheanyaebosi@gmail.com';
console.log(`Hello World, this is ${fullName} with HNGi7 ID ${id} using ${language} for stage 2 task. ${email}`); 

