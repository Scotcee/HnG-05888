let pre = 'Hello World, this is';
let fin = 'for stage 2 task.';
let id = 'HNG-05543';
let email = ' p.akinyemi@yahoo.com'
console.log(pre + ' Akinyemi Bosun with HNGi7 ID ' + id + ' using JavaScript ' + fin);
