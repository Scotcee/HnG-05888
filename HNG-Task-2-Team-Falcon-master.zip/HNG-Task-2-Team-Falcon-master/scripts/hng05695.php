<?php

$name = "Catherine Chen";
$id = "HNG-05695";
$lang = "PHP";
$email = "bluebirid228@gmail.com";

echo "Hello World, this is $name with HNGi7 ID $id using $lang for stage 2 task. $email";

?>
