const fullName = 'Omogbemeh Praise';
const HNG_ID = 'HNG-05697';
const language = 'Java Script';
const email = 'onosithena@gmail.com';

console.log(`Hello World, this is ${fullName} with HNGI7 ID ${HNG_ID} using ${language} for stage 2 task. ${email}`)

