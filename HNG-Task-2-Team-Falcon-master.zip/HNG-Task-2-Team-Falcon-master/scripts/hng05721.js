console.log ("Hello World, this is Onyinyechukwu Marichris Udeobi with HNGi7 ID 05721 using JavaScript for stage 2 task. onyinyeudeobi2@gmail.com");
