var onyee = 'Hello World, this is Peace Onyehanere with HNGi7 ID HNG-05750 using JavaScript for stage 2 task. peace.onyehanere@gmail.com';

console.log(onyee);
