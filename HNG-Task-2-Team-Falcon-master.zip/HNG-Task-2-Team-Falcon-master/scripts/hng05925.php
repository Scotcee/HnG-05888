<?php 

    $fullname = 'Peter Okusanya';
    $hngid    =  'HNG-05925';
    $language =  'PHP';
    $emailaddress = 'dennyokus@gmail.com';

    $tasktwo = "Hello World, this is {$fullname} with HNGi7 ID {$hngid} using {$language} for stage 2 task. dennyokus@gmail.com"; 
    


    echo $tasktwo;





?>
