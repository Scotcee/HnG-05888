const details = {
    firstName: "Habeeb",
    lastName: "Jimoh",
    HNG_id: "HNG-06056",
    email: "jimohhabeeb@hotmail.com",
};

const output = (`Hello World, this is ${details.firstName} ${details.lastName} with HNGi7 ID ${details.HNG_id} using JavaScript for stage 2 task. ${details.email}`);

console.log(output);