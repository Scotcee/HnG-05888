const details = {
    firstName: "Ajayi",
    lastName: "Solomon",
    HNG_id: "HNG-06084",
    email: "temmyjay001@gmail.com",
};

const output = (`Hello World, this is ${details.firstName} ${details.lastName} with HNGi7 ID ${details.HNG_id} using JavaScript for stage 2 task. ${details.email}`);

console.log(output);
