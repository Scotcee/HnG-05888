<?php
  	$HNG_ID = 'HNG-06468';
	$Fullname = 'Mutiulahi Tesleem Olamilekan';
	$Email = 'tesleemolamilekan902@gmail.com';
	$Language = 'PHP';
	echo "Hello World, this is [$Fullname] with HNGi7 ID [$HNG_ID] using [$Language] and email [$Email] for stage 2 task.";

?>
