Fullname='Ademola Cynthia Oreoluwa';
ID='HNG-06702';
language='python' ;
email='ooreeademola@gmail.com';
print ('Hello World, this is {} with HNG i7 ID {} using {} for stage 2 task'.format(Fullname,language,ID))
