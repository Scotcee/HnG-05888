let details = {
    name: "Oluwaferanmi Ogunrinola",
    language: "Javascript",
    hngID: "HNG 0842",
    email: "ooluwaferanmi80@gmail.com"
};
const message = `Hello World, this is ${details.name} with HNGID ${details.hngID} using ${details.language} for task 2. ${details.email}`;
console.log(message);
