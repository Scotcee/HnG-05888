#Using default parameters, define hello function
def hello(full_name = 'Fortune Chuku', hng_ID = '02755', language = 'python', email = 'chukufortune@gmail.com'):
    print(f'Hello World, this is {full_name} with HNGi7 ID {hng_ID} using {language} for stage 2 task. {email}') 

hello() #call function

git commit -m "used python to provide my personal details"

