<?php
$name = "Milind krishna";
$hngi7_id = " 00344";
$language = "PHP" ;
$mail = "milindkrishna69233@gmail.com";
$message = "Hello World! this is ". $name. " with hngi7id = ". $hngi7_id." using ". $language. " for stage two task ".$mail;
echo "$message" ;
?>
