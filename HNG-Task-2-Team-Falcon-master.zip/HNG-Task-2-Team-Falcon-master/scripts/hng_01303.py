#Hello,this is Yamini
#Task:stage 2 assignment 
uName="Kankanala Yamini"
identification="HNG-01303"
lan="python"
email="yaminichowdary11111999@gmail.com"
print("Hello World, this is " + uName + " with HNGi7 ID " + identification + " using " + lan + " for stage 2 task. " + email)
