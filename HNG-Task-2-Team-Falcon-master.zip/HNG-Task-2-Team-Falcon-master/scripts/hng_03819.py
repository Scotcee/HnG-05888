fullname = "Isaac Kamula"
hngid = "HNG-03819"
language = "Python"
email = "kamulaisaac@gmail.com"

def output(name,id,language,email):
    print("Hello World, this is {} with HNGi7 ID {} using {} language for stage 2 task.{}".format(name,id,language,email))

output(fullname,hngid,language,email)
