   val name : String = "Prosper Ekwerike"
   val hngId : String = "HNG-05129"
   val language : String = "Kotlin"
   println("Hello World, this is ${name} with HNGi7 ID ${hngId} using ${language} for stage 2 task")
