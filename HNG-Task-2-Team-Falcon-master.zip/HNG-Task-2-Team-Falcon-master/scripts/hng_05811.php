<!DOCTYPE html>
<html lang = "en-us">
<head><title>HNGi7 stage 2 task</title></head>
<body>
<?php
$name = "Omisakin Oluwapelumi";
$id = "05811";
$language = "PHP";
$email = "omisakin205@gmail.com";
echo "Hello World,
this is $name,
with HNGi7 ID {$id},
using {$language}  with email {$email} for stage 2 task";
?>
</body>
</html>
