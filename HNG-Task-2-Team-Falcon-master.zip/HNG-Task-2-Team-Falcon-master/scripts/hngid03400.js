var input = ["Abasiono" + " Timothy" + " with HNGi7ID-03400"];
console.log("Hello World," + " this is" + " " + input + " using javascript for stage 2 task" + " email@abasionotimothy@gmail.com");
