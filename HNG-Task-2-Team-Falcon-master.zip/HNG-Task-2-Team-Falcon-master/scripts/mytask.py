details = input ("Hello World, this is [Osakinle Dare Thomas] with HNGi7 ID [00937] using [C#] for stage 2 task.[Thomasdreh@gmail.com]")


print (details)