// JavaScript source code
"Hello World, this is Oke Olaniyi with HNGi7 ID 02724 using JavaScript for stage 2 task"